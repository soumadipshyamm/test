import { PutObjectCommand } from "@aws-sdk/client-s3";
import { bucketName, s3Client, s3Url } from "../../config/aws.config";
import { getFileExtension } from "../../utils/helper";

export const uploadImageToS3Service = async (key: string, fileName: string, thumbnailBuffer: Buffer) => {
	const keyName = `${key}/${fileName}`;
	const fileExtension = getFileExtension(fileName);
	const command = new PutObjectCommand({
		Bucket: bucketName,
		Key: keyName,
		Body: thumbnailBuffer,
		ACL: "public-read",
	});
	console.log("---------------------- Uploading to S3 with key:", command, fileExtension);

	try {
		const response = await s3Client.send(command);
		if (response) {
			return `${s3Url}/${keyName}`;
		}
		return null;
	} catch (err) {
		console.error(err);
	}
};

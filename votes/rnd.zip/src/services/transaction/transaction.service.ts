import { TRANSACTION_STATUS } from "../../constants/status/status";
import transactionModel from "../../model/transaction.model";
import transactionLogsModel from "../../model/transactionLogs.model";

const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

export const transaction = async (transactionPayload: any) => {
	try {
		const transactionData = {
			payment_intent_id: transactionPayload.payment_intent_id,
			member_objectId: transactionPayload.member_objectId,
			competition_objectId: transactionPayload.competition_objectId,
			type: transactionPayload.type,
			payment_type: transactionPayload.payment_type,
			payment_status: transactionPayload.payment_status,
			amount: transactionPayload.amount,
			transaction_date: transactionPayload.transaction_date,
			message: transactionPayload.message,
			payment_data: transactionPayload.payment_data,
			transaction_status: transactionPayload.transaction_status
		};
		const transactionResult = await new transactionModel(transactionData).save();
		await transactionLog({ ...transactionPayload, transaction_objectId: transactionResult._id });
		return transactionResult;
	} catch (error: any) {
		console.error("Transaction Error", error);
		throw error; // Rethrow the error for further handling
	}
};
export const transactionStatusUpdate = async (transactionPayload: any) => {
	try {
		const updateData = {
			payment_status: transactionPayload.payment_status,
			respons_data: transactionPayload.respons_data ? transactionPayload.respons_data : null
		};
		// Find the transaction by id
		const transactionResult = await transactionModel.findOne({ _id: transactionPayload.id });
		// Update the transaction
		const updatedTransaction = await transactionModel.findOneAndUpdate(
			{ _id: transactionPayload.id }, // Query to find the document by id
			{ $set: updateData }, // Update operation
			{ new: true } // Option to return the updated document
		);
		console.log("------------------------updatedTransaction", updatedTransaction);

		// await transactionLog({ ...transactionPayload, transaction_objectId: transactionResult?._id });
		return updatedTransaction;
	} catch (error: any) {
		console.error("Transaction Error", error);
		throw new Error(`Transaction update failed: ${error.message}`); // Rethrow with a custom message
	}
};
export const transactionLog = async (transactionPayload: any) => {
	console.log(transactionPayload);
	try {
		// Prepare log data
		const logData = {
			transaction_objectId: transactionPayload?.transaction_objectId,
			payment_intent_id: transactionPayload?.payment_intent_id,
			member_objectId: transactionPayload?.member_objectId,
			payment_status: TRANSACTION_STATUS?.pending,
			payment_type: transactionPayload?.payment_type,
			amount: transactionPayload?.amount,
			transaction_date: transactionPayload?.transaction_date,
			message: transactionPayload?.message,
			payment_data: transactionPayload?.payment_data
		};
		await new transactionLogsModel(logData).save();
	} catch (error: any) {
		console.error("Transaction Log Error", error);
		throw error; // Rethrow the error for further handling
	}
};

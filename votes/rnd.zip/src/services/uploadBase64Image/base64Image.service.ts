import * as mime from 'mime-types';
import { uploadImageToS3Service } from '../uploadImageS3/UploadImageS3';
import { getFileExtension } from '../../utils/helper';

export const uploadImageBase64Service = async (base64Image: string, folderName: string): Promise<any> => {

	if (!base64Image) {
		return null;
		// throw new Error('No image provided');
	}
	const base64Data = Buffer.from(base64Image.replace(/^data:image\/\w+;base64,/, ''), 'base64');

	const mimeMatch = base64Image.match(/^data:(image\/\w+);base64,/);
	if (!mimeMatch) {
		throw new Error('Invalid base64 image format - missing MIME type');
	}
	const mimeType = mimeMatch[1];
	const extension = getFileExtension(mimeType);
	const fileName = `${Date.now()}.${extension}`;
	const photoBuffer = base64Data;
	const photoUrl = await uploadImageToS3Service(folderName, fileName, photoBuffer);
	return photoUrl;
};
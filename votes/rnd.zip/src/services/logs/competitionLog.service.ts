// import CompetitionActivityLogsModel from "../../model/competitionActivityLogs.model";

// export const competitionsActivityLog = async (competitionPayload: any) => {
// 	try {
// 		const competitionsActivityLog = {

// 		};
// 		await new CompetitionActivityLogsModel(competitionsActivityLog).save();
// 	} catch (error: any) {
// 		console.log("Competitions Activity Log Error", error);
// 		throw error;
// 	}
// };
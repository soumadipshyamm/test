import exp from "node:constants";
import { getCurrentMongoDBFormattedDate } from "../date/date.service";
import { STRIPE_SECRET_KEY } from "../../config/config";
import { transaction } from "../transaction/transaction.service";
const stripe = require('stripe')(STRIPE_SECRET_KEY);
// const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

export const createStripePaymentIntents = async (memberId: string, competitionId: string, amount: number, transaction_status: string, message: string, type: string = 'card', status: string = "PENDING"): Promise<any> => {

	// Validate amount
	if (amount <= 0) {
		throw new Error("Amount must be greater than zero.");
	}

	const paymentIntent = await stripe.paymentIntents.create({
		amount: amount * 100, // Convert amount to cents
		currency: 'usd',
		metadata: { memberId, type },
	});

	// console.log("paymentIntent", paymentIntent)
	const transactionPayload = {
		payment_intent_id: paymentIntent.id,
		member_objectId: memberId,
		competition_objectId: competitionId,
		type: "card",
		amount: amount,
		payment_status: status,
		payment_type: type,
		// status: "pending",
		transaction_date: getCurrentMongoDBFormattedDate(),
		payment_data: paymentIntent,
		transaction_status: transaction_status,
		message: message
	};

	// console.log("=============processPayment===================", transactionPayload);

	const result = await transaction(transactionPayload);
	return result;
}

export const verifyPaymentViaStripe = async (paymentIntentId: string) => {
	try {
		const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
		return paymentIntent;
	} catch (error) {
		throw new Error("Failed to retrieve payment intent");
	}
};

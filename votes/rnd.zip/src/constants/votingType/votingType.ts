export const VOTINGTYPE = {
	free: "FREE",
	paid: "PAID"
};

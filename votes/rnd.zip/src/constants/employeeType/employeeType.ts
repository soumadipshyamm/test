export const EMPLOYEE_TYPE = {
	worker: "WORKER",
	administrator: "ADMINISTRATOR",
}
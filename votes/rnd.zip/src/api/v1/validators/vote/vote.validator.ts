import Joi from "joi";

export const voteValidator = Joi.object({
	competition_object_id: Joi.string().required(),
	participant_object_id: Joi.string().required(),
	round_object_id: Joi.string().required()
});

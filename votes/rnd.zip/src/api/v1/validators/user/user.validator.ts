import Joi from "joi";
import { GENDER } from "../../../../constants/gender/gender";
import { CONTACT_LABEL } from "../../../../constants/contactLabel/contactLabel";
import { ROLES } from "../../../../constants/roles/roles";

export const userValidator = Joi.object({
	role: Joi.string().valid(ROLES.super_admin, ROLES.admin, ROLES.competition_creator, ROLES.individual_voter, ROLES.participant).required(),
	first_name: Joi.string().min(1).max(30).required(),
	middle_name: Joi.string().allow('').max(30),
	last_name: Joi.string().min(1).max(30).required(),
	user_name: Joi.string().alphanum().min(3).max(30).required(),
	gender: Joi.string().valid(GENDER.male, GENDER.female, GENDER.others).when('role', {
		is: "MEMBER",
		then: Joi.optional().allow(''),
		otherwise: Joi.required()
	}),
	address_line_1: Joi.string().max(100).when('role', {
		is: "MEMBER",
		then: Joi.optional().allow(''),
		otherwise: Joi.required()
	}),
	address_line_2: Joi.string().allow('').max(100),
	city: Joi.string().max(50).when('role', {
		is: "MEMBER",
		then: Joi.optional().allow(''),
		otherwise: Joi.required()
	}),
	state: Joi.string().max(50).when('role', {
		is: "MEMBER",
		then: Joi.optional().allow(''),
		otherwise: Joi.required()
	}),
	country: Joi.string().max(50).when('role', {
		is: "MEMBER",
		then: Joi.optional().allow(''),
		otherwise: Joi.required()
	}),
	zip: Joi.string().length(6).pattern(/^[0-9]+$/).when('role', {
		is: "MEMBER",
		then: Joi.optional().allow(''),
		otherwise: Joi.required()
	}),
	contact_label: Joi.string().valid(CONTACT_LABEL.home, CONTACT_LABEL.business, CONTACT_LABEL.mail, CONTACT_LABEL.mobile, CONTACT_LABEL.other).when('role', {
		is: "MEMBER",
		then: Joi.optional().allow(''),
		otherwise: Joi.required()
	}),
	phone_number: Joi.string().pattern(/^[0-9]+$/).when('role', {
		is: "MEMBER",
		then: Joi.optional().allow(''),
		otherwise: Joi.required()
	}),
	phone_extension: Joi.string().allow('').optional(),
	company: Joi.string().max(100).allow(''),
	date_of_birth: Joi.date(),
	discription: Joi.string().allow('').optional(),
});

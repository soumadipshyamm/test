import Joi from "joi";
import CompetitionModel from "../../../../model/competition.model";

export const competitionAcceptRejectValidator = Joi.object({
	_id: Joi.string().required(),
	status: Joi.string()
		.valid('ACTIVE', 'REJECTED')
		.required()
		.messages({
			'any.required': 'Status is required',
			'string.valid': 'Status must be either active or rejected',
		}),
	remarks: Joi.string().when('status', {
		is: 'REJECTED',
		then: Joi.required().messages({
			'any.required': 'Rejected Reason is required',
		}),
	}),

}).custom(async (value, helpers) => {
	const competition = await CompetitionModel.findById(value._id);
	if (!competition) {
		return helpers.error('any.invalid', { message: 'Competition not found' });
	}
	if (competition.status === 'REJECTED') {
		return helpers.error('any.invalid', { message: 'Cannot change status from rejected' });
	}
	return value;
});

import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
const multer = require('multer');
const upload = multer();
import { validators } from "../../validators";
import { login } from "../../controllers/auth/login/login.controller";
import registration from "../../controllers/auth/registration/index";
import memberAuth from "../../../../middlewares/auth/memberAuth.middleware";

const router = express.Router();

// router.route("/login").post(login);
router.route("/login").post(validator(validators.loginValidator, null), login);
router.route("/registration/super-admin").post(validator(validators.superAdminregistrationValidator, null), registration.superAdminRegistration);

router.route("/registration/admin").post(registration.adminRegistration);
router.route("/registration/member").post(upload.fields([{ name: "upload_front_side", maxCount: 1 }, { name: "upload_back_side", maxCount: 1 }]), validator(validators.memberRegistrationValidator, null), registration.memberRegistration);
// router.route("/registration/member").post(upload.none(), validator(validators.memberRegistrationValidator, null), registration.memberRegistration);

router.route("/email-verification-with-password-change").post(registration.emailVerificationWithPasswordChange);

// make a member role upgrade request
router.route("/member-role-upgrade").put(memberAuth, upload.fields([{ name: "upload_front_side", maxCount: 1 }, { name: "upload_back_side", maxCount: 1 }]), registration.makeMemberRoleUpgradeRequest);
module.exports = router;



import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
import registration from "../../controllers/auth/registration";
import { validators } from "../../validators";
import {
	addCompetitionType,
	listCompetitionTypes,
	getCompetitionTypeDetails,
	updateCompetitionType,
	deleteCompetitionType,
	getCompetitionTypeSearch
} from "../../controllers/competitionManagment/competitionTypeManagment.controller";
import {
	competitionAcceptReject,
	listCompetitions,
	competitionCreatorAcceptRejectByAdmin,
	competitionCreatorAcceptRejectList
} from "../../controllers/competitionManagment/competition.controller";
import groupOwnerAuth from "../../../../middlewares/auth/groupOwnerAuth.middleware";
import { updateFeaturePermission } from "../../controllers/GroupOwner/userManagment/userManagment.controller";
import {
	addVotePackage,
	listVotePackage,
	getVotePackageDetails,
	updateVotePackage,
	deleteVotePackage,
	addVotePackagePrice,
	listVotePackagePrice,
	detailsVotePackagePrice,
	updteVotePackagePrice,
	deleteVotePackagePrice

} from "../../controllers/GroupOwner/votePackageManagment/votePackageManagment.controller";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";

const router = express.Router();

router.route("/add-admin").post(groupOwnerAuth, validator(validators.adminEntryValidator, null), registration.addAdmin);
router.route("/list-admin").get(groupOwnerAuth, registration.listAdmin);
router.route("/update-permission").put(groupOwnerAuth, updateFeaturePermission);

//competition managment
router.route("/competition-type/add").post(groupOwnerAuth, validator(validators.competitionTypeAddValidator, null), addCompetitionType);
router.route("/competition-type/list").get(generalAuth, listCompetitionTypes);
router.route("/competition-type/details/:id").get(generalAuth, getCompetitionTypeDetails);
router.route("/competition-type/update/:id").put(groupOwnerAuth, updateCompetitionType);
router.route("/competition-type/delete/:id").delete(groupOwnerAuth, deleteCompetitionType);
router.route("/competition-type/search/:name").get(generalAuth, getCompetitionTypeSearch);

//vote managment
router.route("/vote-package/").post(groupOwnerAuth, validator(validators.votePackageAddValidator, null), addVotePackage);
router.route("/vote-package/").get(generalAuth, listVotePackage);
router.route("/vote-package/:id").get(generalAuth, getVotePackageDetails);
router.route("/vote-package/:id").put(groupOwnerAuth, updateVotePackage);
router.route("/vote-package/:id").delete(groupOwnerAuth, deleteVotePackage);

//vote package price managment
router.route("/vote-package-price/").post(groupOwnerAuth, addVotePackagePrice);
router.route("/vote-package-price/:vote_package_id").get(generalAuth, listVotePackagePrice);
router.route("/vote-package-price/:package_id/:package_price_id").get(generalAuth, detailsVotePackagePrice);
router.route("/vote-package-price/:package_id/:package_price_id").put(groupOwnerAuth, updteVotePackagePrice);
router.route("/vote-package-price/:package_id/:package_price_id").delete(groupOwnerAuth, deleteVotePackagePrice);

//Competition Managment
router.route("/competition-accept-reject").put(groupOwnerAuth, validator(validators.competitionAcceptRejectValidator, null), competitionAcceptReject);
router.route("/competition-creator-accept-reject").patch(groupOwnerAuth, competitionCreatorAcceptRejectByAdmin);
router.route("/competition-creator-accept-reject/:status?").get(groupOwnerAuth, competitionCreatorAcceptRejectList);

module.exports = router;
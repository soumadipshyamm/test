import express from "express";
import {
	listCompetitions,
	getCompetitionDetails,
	filterCompetitions,
	getVotingHistory,
	currentRound
} from "../../controllers/competitionManagment/competition.controller";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
import { getParticipantRoundStatuses, getAllparticipantsList, getCompetitionDetailsWithRoundAndParticipants } from "../../controllers/competitionManagment/participant.controller";
import { getVotePackageDetails, getExtraVotePackagesList } from "../../controllers/GroupOwner/votePackageManagment/votePackageManagment.controller";

const router = express.Router();

//competition managment
router.route("/competition").get(generalAuth, listCompetitions);
router.route("/competition/:id").get(generalAuth, getCompetitionDetails);
router.route("/filter-competition").post(generalAuth, filterCompetitions);
router.route("/voting-history").get(generalAuth, getVotingHistory);

//participant managment
router.route("/participant/participated-competitions-list/:status?").get(generalAuth, getParticipantRoundStatuses);
router.route("/all-participants/list/:competitionId?/:roundId?").get(generalAuth, getAllparticipantsList);
router.route("/get-competition-details-with-round/:competitionId?/:roundId?").get(generalAuth, getCompetitionDetailsWithRoundAndParticipants);
// Get current round of competition
router.route("/current-round").get(currentRound);

/// voter management
router.route("/voter/packaged-list/:competitionId?/:roundId?").get(generalAuth, getExtraVotePackagesList);

module.exports = router;
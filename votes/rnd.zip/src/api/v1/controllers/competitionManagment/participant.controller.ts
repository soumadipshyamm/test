import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import { currentRoundss, get_round_status, getDetailsByEmail, getRoundStatus, getTimeStatus, totalVotesCount } from "../../../../utils/helper";
import ParticipantModel from "../../../../model/participant.model";
import CompetitionModel from "../../../../model/competition.model";
import SavedCompetitionModel from "../../../../model/savedCompetition.model";
import moment from 'moment';
import { uploadImageToS3Service } from "../../../../services/uploadImageS3/UploadImageS3";
import VoteModel from "../../../../model/vote.model";
import VotingSubscriptionModel from "../../../../model/votingSubscription.model";
import mongoose from "mongoose";
import { PARTICIPATION_STATUS, PAYMENT_STATUS, TRANSACTION_STATUS } from "../../../../constants/status/status";
import { createStripePaymentIntents, verifyPaymentViaStripe } from "../../../../services/payment/stripe.service";
import { transactionStatusUpdate } from "../../../../services/transaction/transaction.service";
import dayjs from "dayjs";
import { log } from "node:console";
import VotePackageModel from "../../../../model/votePackage.model";
import { stat } from "node:fs";
export const addParticipant = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competition_object_id, round_id } = req.body
		if (!competition_object_id) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Competition ID required."
			});
		}
		let user = await getDetailsByEmail(req.user.email);
		const competition = await CompetitionModel.findById(competition_object_id).select('name rounds');
		if (!competition) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Competition not found."
			});
		}
		if (!user?._id) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "User not found."
			});
		}
		const round = competition.rounds[0];
		const round_object_id = round ? round_id : null;
		// const round_object_id = round ? round._id : null;
		const round_no = round ? round.round_no : null;
		const competition_name = competition.name;
		let participantInstance;
		let stripePaymentDetails;
		const existingParticipant = await ParticipantModel.findOne({
			participant_object_id: user?._id,
			competition_object_id: competition_object_id,
			round_object_id: round_object_id
		});
		if (existingParticipant?.participant_payment_status === 'PENDING' || existingParticipant?.participant_payment_status === null) {
			const stripePaymentIntent = await createStripePaymentIntents(user._id.toString(), competition_object_id, round?.price, "DEBITED", "COMPETITION PARTICIPATION");
			stripePaymentDetails = stripePaymentIntent.payment_data;
			if (!stripePaymentIntent || !stripePaymentIntent.payment_status) {
				return res.status(StatusCodes.BAD_REQUEST).json({
					message: MESSAGE.post.custom("Failed to create payment intent.")
				});
			}
			const paymentData = {
				participant_payment_status: stripePaymentIntent.payment_status,
				participant_payment_intant_id: stripePaymentIntent.payment_intent_id,
				transaction_object_id: stripePaymentIntent.id
			};
			participantInstance = await ParticipantModel.findByIdAndUpdate(existingParticipant?._id, paymentData, { new: true, runValidators: true });
		} else if (existingParticipant?.participant_payment_status === 'SUCCESS') {
			return res.status(StatusCodes.CONFLICT).json({
				message: MESSAGE.custom("You are already a participant in this round."),
				Result: {}
			});
		} else {
			const stripePaymentIntent = await createStripePaymentIntents(user._id.toString(), competition_object_id, round?.price, "DEBITED", "COMPETITION PARTICIPATION");
			stripePaymentDetails = stripePaymentIntent.payment_data;
			const data = {
				participant_object_id: user._id,
				competition_object_id: competition_object_id,
				round_object_id: round_object_id,
				competition_name: competition_name,
				round_no: round_no,
				participant_name: user?.first_name + ' ' + user?.last_name,
				participant_payment_status: stripePaymentIntent?.payment_status,
				participant_payment_intant_id: stripePaymentIntent?.payment_intent_id,
				transaction_object_id: stripePaymentIntent?.id
			};
			participantInstance = await ParticipantModel.create(data);
		}
		return res.status(StatusCodes.CREATED).json({
			message: MESSAGE.post.succ,
			Result: { participantInstance, stripePaymentDetails }
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.post.fail,
			error
		});
	}
};
export const participantRePayment = async (req: Request, res: Response): Promise<any> => {
	const { competition_object_id, round_object_id } = req.body;
	try {
		// Retrieve user details and validate
		const user = await getDetailsByEmail(req.user.email);
		if (!user?._id) {
			return res.status(StatusCodes.NOT_FOUND).json({ message: "User not found." });
		}
		// Find the competition and its first round
		const competition = await CompetitionModel.findById(competition_object_id).select('name rounds');
		if (!competition || !competition.rounds.length) {
			return res.status(StatusCodes.NOT_FOUND).json({ message: "Competition or round not found." });
		}
		const round = competition.rounds[0];
		// Check for existing participant
		const existingParticipant = await ParticipantModel.findOne({
			participant_object_id: user._id,
			competition_object_id,
			round_object_id
		});
		// Create a Stripe payment intent
		const stripePaymentIntent = await createStripePaymentIntents(
			user._id.toString(),
			competition_object_id,
			round.price,
			"DEBITED",
			"COMPETITION PARTICIPATION"
		);
		// Prepare payment data for updating the participant
		const paymentData = {
			participant_payment_status: stripePaymentIntent.payment_status,
			participant_payment_intant_id: stripePaymentIntent.payment_intent_id,
			transaction_object_id: stripePaymentIntent.id
		};
		// Update existing participant payment details or handle non-existing participant
		if (existingParticipant) {
			const updatedPayment = await ParticipantModel.findByIdAndUpdate(
				existingParticipant._id,
				{ $set: paymentData },
				{ new: true, runValidators: true } // Removed upsert to ensure only updating
			);
			return res.status(StatusCodes.CREATED).json({
				message: MESSAGE.post.succ,
				result: { updatedPayment, stripePaymentDetails: stripePaymentIntent.payment_data }
			});
		}
		return res.status(StatusCodes.NOT_FOUND).json({
			message: MESSAGE.post.fail,
			result: {}
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: "An error occurred during the payment process.",
			error: error
		});
	}
};
export const verifyPayment = async (req: Request, res: Response): Promise<any> => {
	const { id } = req.params;
	const { paymentIntent_id } = req.body;
	// Validate paymentIntent_id
	if (!paymentIntent_id) {
		return res.status(StatusCodes.UNPROCESSABLE_ENTITY).json({
			status: false,
			message: "Stripe order Id is required",
			data: {}
		});
	}
	try {
		// Retrieve the existing participant
		const existingParticipant = await ParticipantModel.findById(id).lean();
		if (!existingParticipant) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Participant not found.",
				data: {}
			});
		}
		// Retrieve the Payment Intent from Stripe
		const paymentIntent = await verifyPaymentViaStripe(paymentIntent_id);
		// Check if the Payment Intent exists and is successful
		if (paymentIntent && paymentIntent.status === "succeeded") {
			const paymentData = {
				participant_payment_status: paymentIntent.status === "succeeded" ? TRANSACTION_STATUS.success : TRANSACTION_STATUS.cancel, // Correctly set the payment status
			};
			// Update the participant's payment status
			const updatedPayment = await ParticipantModel.findByIdAndUpdate(
				existingParticipant._id,
				{ $set: paymentData },
				{ new: true, runValidators: true }
			);
			// Prepare transaction payload
			const transactionPayload = {
				id: existingParticipant.transaction_object_id,
				payment_status: paymentIntent?.status === "succeeded" ? TRANSACTION_STATUS.success : TRANSACTION_STATUS.cancel,
			};
			// Update transaction status
			const data = await transactionStatusUpdate(transactionPayload);
			// if (data?.payment_status === "SUCCESS") {
			return res.status(StatusCodes.OK).json({
				message: MESSAGE.custom("Transaction fetched successfully!"),
				result: data
			});
			// }
		} else {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Payment not successful!"),
				data: {}
			});
		}
	} catch (error) {
		console.error("Payment verification error:", error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("Transaction unsuccessful!"),
			error: error
		});
	}
};
export const participantCompetitionDetails = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competitionId, roundId, participantId } = req.params;
		// Fetch participant details using email
		const participantDetails = await getDetailsByEmail(req.user.email);
		if (!participantDetails) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: MESSAGE.get.fail,
				error: "Participant details not found."
			});
		}
		// Get the current round for the competition
		const current_round = await currentRoundss(competitionId.toString());

		if (!current_round) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: MESSAGE.get.fail,
				error: "Current round not found."
			});
		}

		// Fetch competition details for the participant
		const fetchCompetitionDetails = await ParticipantModel.find({
			competition_object_id: competitionId,
			participant_object_id: participantId ? participantId : participantDetails._id,
			round_object_id: roundId ? roundId : current_round._id,
			// participant_payment_status: "SUCCESS",
			// status: { $in: [PARTICIPATION_STATUS.participating, PARTICIPATION_STATUS.participated] }
		}).populate('competition_object_id')
			.populate('transaction_object_id')
			.populate('participant_object_id')
			.populate('round_object_id')
			.populate('round_object_id.additional_vote_package')
			.lean();

		if (!fetchCompetitionDetails || fetchCompetitionDetails.length === 0) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: MESSAGE.get.fail,
				error: "No competition details found for the participant."
			});
		}
		const additional_vote_packages = await VotePackageModel.find({
			_id: { $in: current_round.additional_vote_package }
		}).lean();
		const totalVotes = await totalVotesCount(competitionId as any, roundId as any, participantId as any)
		console.log("==================totalVotes", totalVotes);

		const freeVoteCheck = await VoteModel.countDocuments({
			participant_object_id: participantDetails._id,
			round_object_id: current_round._id,
			competition_object_id: competitionId,
			voting_type: "FREE"
		});
		const hasReceivedFreeVotes = freeVoteCheck > 0 ? false : true;
		// Enrich the competition details with current round information
		const enrichedCompetitionDetails = fetchCompetitionDetails.map(participant => ({
			...participant,
			current_round,
			additional_vote_packages,
			is_free_votes: hasReceivedFreeVotes,
			total_votes_count: totalVotes
		}));
		// Return the enriched competition details
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			Result: enrichedCompetitionDetails
		});
	} catch (error) {
		console.error("Error fetching participant competition details:", error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.get.fail,
			error: "An error occurred while fetching competition details."
		});
	}
};
export const upcommingCompetitionList = async (req: Request, res: Response): Promise<any> => {
	try {
		const currentDate = new Date();
		const userDetails = await getDetailsByEmail(req.user.email);
		//  Fetch upcoming competitions
		const fetchUpcomingCompetitions = await CompetitionModel.find({
			status: "ACTIVE",
			// challenge_start_date: { $gte: currentDate }
		})
			.populate("creator_company")
			.populate("created_by")
			.populate("competition_type")
			.lean();

		if (!fetchUpcomingCompetitions.length) {
			return res.status(StatusCodes.OK).json({
				message: "No upcoming competitions found.",
				Result: []
			});
		}
		//  Fetch participant details

		const participant_object_id = userDetails?._id;
		const savedCompetitions = await SavedCompetitionModel.find({ participant_object_id }).lean();
		// Create a set of saved competition IDs for quick lookup
		const savedCompetitionIds = new Set(savedCompetitions.map(comp => comp.competition_object_id.toString()));

		const competitionsWithMetadata = await Promise.all(
			fetchUpcomingCompetitions.map(async (competition) => {

				const current_round = await currentRoundss(competition._id.toString());
				if (!current_round || current_round.status !== 'upcoming') {
					console.warn(`No valid ongoing round for competition: ${competition._id}`);
					return null; // Skip if no valid ongoing round
				}
				//  Get participant details for CURRENT ROUND + USER
				const participantDetails = await ParticipantModel.find({
					round_object_id: current_round?._id,
					participant_object_id,
					competition_object_id: competition?._id.toString()
				}).lean();
				const enrolled_competition = participantDetails.some(participant =>
					participant.participant_payment_status == "SUCCESS"
				);
				return {
					...competition,
					competition_saved_status: savedCompetitionIds.has(competition._id.toString()),
					current_round, //  Dynamic round
					participantDetails,
					enrolled_competition //  Dynamic participant data
				};
			})
		);
		const validCompetitions = competitionsWithMetadata.filter(
			(comp): comp is NonNullable<typeof comp> => comp !== null
		);
		//  Final Response
		return res.status(StatusCodes.OK).json({
			message: "Fetched upcoming competitions with metadata",
			Result: validCompetitions,
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error: error,
		});
	}
};
export const completedCompetitionList = async (req: Request, res: Response): Promise<any> => {
	try {
		const userDetails = await getDetailsByEmail(req.user.email);
		const participant_object_id = userDetails?._id;
		const completedCompetitions = await CompetitionModel.find({
			status: "COMPLETED"
		}).populate("creator_company").populate("created_by").populate("competition_type").lean();

		return res.status(StatusCodes.OK).json({
			message: "Fetched upcoming competitions with metadata",
			Result: completedCompetitions,
		});
	} catch (error) {
		console.error('Error in ongoingCompetitionList:', error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.get.fail,
			error: error instanceof Error ? error.message : 'Unknown error',
		});
	}
}
export const completedCompetitionRoundList = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competitionId } = req.params;
		const roundList = await CompetitionModel.find({
			_id: competitionId
		}).lean();



		return res.status(StatusCodes.OK).json({
			message: "Fetched upcoming competitions with metadata",
			Result: roundList
		});
	} catch (error) {
		console.error('Error in ongoingCompetitionList:', error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.get.fail,
			error: error instanceof Error ? error.message : 'Unknown error',
		});
	}
}
export const completedCompetitionRoundDetailsList = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competitionId, roundId } = req.params;
		const roundParticipantList = await ParticipantModel.find({
			competition_object_id: competitionId,
			round_object_id: roundId
		}).populate('competition_object_id').populate('round_object_id').populate('participant_object_id').lean();
		return res.status(StatusCodes.OK).json({
			message: "Fetched upcoming competitions with metadata",
			Result: roundParticipantList
		});
	} catch (error) {
		console.error('Error in ongoingCompetitionList:', error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.get.fail,
			error: error instanceof Error ? error.message : 'Unknown error',
		});
	}
}
export const ongoingCompetitionList = async (
	req: Request,
	res: Response
): Promise<any> => {
	try {
		// 1. Get user details
		const userDetails = await getDetailsByEmail(req.user.email);
		if (!userDetails) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.none,
			});
		}
		const participantObjectId = userDetails._id;
		// 2. Fetch ongoing (active & currently running) competitions
		const fetchOngoingCompetitions = await CompetitionModel.find({
			status: 'ACTIVE',
			challenge_start_date: { $lte: new Date() },
			challenge_end_date: { $gte: new Date() },
		})
			.populate('creator_company')
			.populate('created_by')
			.populate('competition_type')
			.lean();

		if (!fetchOngoingCompetitions || fetchOngoingCompetitions.length === 0) {
			return res.status(StatusCodes.OK).json({
				message: MESSAGE.get.succ,
				Result: [],
			});
		}

		// 3. Fetch saved competitions for this user
		const savedCompetitions = await SavedCompetitionModel.find({
			participant_object_id: participantObjectId,
		}).lean();

		const savedCompetitionIds = new Set(
			savedCompetitions.map((comp) => comp.competition_object_id.toString())
		);

		// 4. Process each competition with its current round and participant data
		const competitionsWithMetadata = await Promise.all(
			fetchOngoingCompetitions.map(async (competition) => {
				try {
					// Get current round (helper should return data, not send res)
					const currentRoundData = await currentRoundss(competition._id.toString());

					if (!currentRoundData || currentRoundData.status !== 'ongoing') {
						console.warn(`No valid ongoing round for competition: ${competition._id}`);
						return null; // Skip if no valid ongoing round
					}

					// Fetch participant details for this user in the current round
					const participantDetails = await ParticipantModel.find({
						round_object_id: currentRoundData._id,
						participant_object_id: participantObjectId,
						competition_object_id: competition._id.toString(),
					}).lean();

					// Determine upload and enrollment status
					const hasUploadedContent = participantDetails.some(
						(p) => p.content?.files && Array.isArray(p.content.files) && p.content.files.length > 0
					);

					const enrolledCompetition = participantDetails.some(
						(p) => p.participant_payment_status === 'SUCCESS'
					);

					// Return enriched competition object
					return {
						...competition,
						competition_saved_status: savedCompetitionIds.has(competition._id.toString()),
						current_round: currentRoundData,
						participantDetails,
						hasUploadedContent,
						enrolled_competition: enrolledCompetition,
					};
				} catch (roundError) {
					console.error(`Error processing competition ${competition._id}:`, roundError);
					return null; // Exclude errored competitions
				}
			})
		);

		// Filter out null values (failed or invalid competitions)
		const validCompetitions = competitionsWithMetadata.filter(
			(comp): comp is NonNullable<typeof comp> => comp !== null
		);

		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			Result: validCompetitions,
		});
	} catch (error) {
		console.error('Error in ongoingCompetitionList:', error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.get.fail,
			error: error instanceof Error ? error.message : 'Unknown error',
		});
	}
};
export const saveCompetition = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competition_object_id } = req.body;
		if (!competition_object_id) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Competition ID required."
			});
		}
		let user = await getDetailsByEmail(req.user.email);
		if (!user) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "User  not found."
			});
		}
		// Check if the record already exists
		const savedCompetitionData = {
			competition_object_id,
			participant_object_id: user._id // Ensure user is not null
		};
		const existingEntry = await SavedCompetitionModel.findOne({
			competition_object_id,
			participant_object_id: user._id
		});
		if (existingEntry) {
			const saveCompetitionInstance = await SavedCompetitionModel.findOneAndDelete({ _id: existingEntry._id });
			return res.status(StatusCodes.OK).json({
				message: MESSAGE.delete.succ,
				Result: saveCompetitionInstance || null
			});
		} else {
			const saveCompetitionInstance = await SavedCompetitionModel.create(savedCompetitionData);
			return res.status(StatusCodes.CREATED).json({
				message: MESSAGE.post.succ,
				Result: saveCompetitionInstance
			});
		}
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.post.fail,
			error: error || error
		});
	}
};
export const saveCompetitionList = async (req: Request, res: Response): Promise<any> => {
	try {
		const user = await getDetailsByEmail(req.user.email);
		const participant_object_id = user?._id;
		const savedCompetitions = await SavedCompetitionModel.find({ participant_object_id })
			.populate({
				path: 'competition_object_id',
				populate: {
					path: 'competition_type'
				}
			})
			.populate('participant_object_id')
			.lean();
		if (!savedCompetitions || savedCompetitions.length === 0) {
			return res.status(StatusCodes.OK).json({
				message: "No saved competitions found for this participant.",
			});
		}
		// Create a set of saved competition IDs, ensuring no null values are processed
		const savedCompetitionIds = new Set(
			savedCompetitions
				.filter(comp => comp.competition_object_id) // Filter out null competition_object_ids
				.map(comp => comp.competition_object_id.toString())
		);
		// Add current_round to each competition
		for (const competition of savedCompetitions as any) {
			if (!competition.competition_object_id || !competition.competition_object_id._id) {
				console.error("Competition object ID is missing for competition:", competition);
				competition.current_round = null; // Set to null or handle as needed
				continue; // Skip to the next iteration
			}
			try {
				const current_round = await currentRoundss(competition.competition_object_id._id.toString());
				competition.current_round = current_round;
				competition.competition_saved_status = true; // Declare and assign the property
			} catch (error) {
				console.error("Error fetching current round for competition:", competition, error);
				competition.current_round = null; // Handle error appropriately
			}
		}
		// Return the saved competitions with current_round populated
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			Result: savedCompetitions
		});
	} catch (error) {
		console.error("Error in saveCompetitionList:", error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error: error || "An error occurred" // Include error message if available
		});
	}
};
export const removeCompetition = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competition_object_id } = req.body
		if (!competition_object_id) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Competition ID required."
			});
		}
		let user = await getDetailsByEmail(req.user.email);
		// Check if the record already exists
		const participant_object_id = user?._id;
		const deletedCompetition = await SavedCompetitionModel.findOneAndDelete({
			competition_object_id,
			participant_object_id
		});
		if (!deletedCompetition) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Competition not found.",
			});
		}
		return res.status(StatusCodes.OK).json({
			message: "Competition deleted successfully.",
			result: deletedCompetition
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.post.fail,
			error
		});
	}
}
export const uploadContent = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competition_object_id, round_object_id, description } = req.body;
		if (!req.files || !("content" in req.files)) {
			return res.status(422).json({
				message: MESSAGE.post.custom("Content not found")
			});
		}
		if (!req.files || !("thumbnail" in req.files)) {
			return res.status(422).json({
				message: MESSAGE.post.custom("thumbnail not found")
			});
		}
		const files = req.files['content'] as Express.Multer.File[];
		if (!files || files.length === 0) {
			return res.status(422).json({
				message: MESSAGE.post.custom("Content files not found")
			});
		}
		const filesData = await Promise.all(files.map(async (file) => {
			const contentName = file.originalname;
			const contentBuffer = file.buffer;
			const fileType = contentName.split('.').pop();
			const isValidFileType = fileType ? await validateFileType(competition_object_id, fileType) : null;
			if (!isValidFileType) {
				return res.status(422).json({
					message: MESSAGE.post.custom("Invalid file type")
				});
			}
			const contentUrl = await uploadImageToS3Service("competition", contentName, contentBuffer);
			return { url: contentUrl, name: contentName };
		}));
		const thumbnail = req.files['thumbnail'] as Express.Multer.File[];
		if (!thumbnail || thumbnail.length === 0) {
			return res.status(422).json({
				message: MESSAGE.post.custom("Content files not found")
			});
		}
		const thumbnailfilesData = await Promise.all(thumbnail.map(async (file) => {
			const contentName = file.originalname;
			const contentBuffer = file.buffer;
			const fileType = contentName.split('.').pop();
			const isValidFileType = fileType ? await validateFileType(competition_object_id, fileType) : null;
			if (!isValidFileType) {
				return res.status(422).json({
					message: MESSAGE.post.custom("Invalid file type")
				});
			}
			const contentUrl = await uploadImageToS3Service("competition_thumbnail", contentName, contentBuffer);
			return { url: contentUrl, name: contentName };
		}));
		const content = { description, upload_date_time: new Date(), files: filesData };
		const thumbnail_url = { files: thumbnailfilesData };
		const user = await getDetailsByEmail(req.user.email)
		if (!user) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: 'User not authenticated.'
			});
		}
		const updatedParticipation = await ParticipantModel.findOneAndUpdate(
			{ competition_object_id, round_object_id, participant_object_id: user._id },
			// { content },
			{ content, thumbnail_url },
			{ new: true }
		);
		if (!updatedParticipation) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Competition not found",
			});
		}
		return res.status(StatusCodes.OK).json({
			message: MESSAGE.put.succ,
			Result: updatedParticipation
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.post.fail,
			error
		});
	}
};
const validateFileType = async (competitionId: string, fileType: string): Promise<boolean> => {
	const competition = await CompetitionModel.findById(competitionId).exec();
	if (!competition) {
		throw new Error("Competition not found");
	}
	return competition.file_type.map(type => type.toLowerCase()).includes(fileType.toLowerCase());
};
export const addVote = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competition_object_id, round_object_id, participant_object_id } = req.body;
		const user = await getDetailsByEmail(req.user.email);
		const freeVoteAvailability = await VoteModel.findOne({
			competition_object_id,
			round_object_id,
			voter_object_id: user?._id,
			// participant_object_id: participant_object_id,
			voting_type: "FREE"
		})
		console.log("==================freeVoteAvailability", freeVoteAvailability);
		console.log("==================totalVotesCount", await totalVotesCount(competition_object_id, round_object_id, participant_object_id));

		// if (freeVoteAvailability) {
		// 	const toObjectId = (id: string) => new mongoose.Types.ObjectId(id);
		// 	const subscriptionAvailability = await VotingSubscriptionModel.aggregate([
		// 		{
		// 			$match: {
		// 				competition_object_id: toObjectId(competition_object_id),
		// 				round_object_id: toObjectId(round_object_id),
		// 				participant_object_id: toObjectId(participant_object_id),
		// 				member_object_id: user?._id,
		// 			},
		// 		},
		// 		{
		// 			$group: {
		// 				_id: null,
		// 				totalVotes: { $sum: "$number_of_votes" },
		// 			},
		// 		},
		// 	]);
		// 	const totalAvailableVotes = subscriptionAvailability[0]?.totalVotes || 0;
		// 	const totalGivenVotes = await VoteModel.find({
		// 		competition_object_id,
		// 		round_object_id,
		// 		voter_object_id: user?._id,
		// 		participant_object_id: participant_object_id,
		// 		voting_type: "PAID"
		// 	})
		// 	if (totalAvailableVotes <= totalGivenVotes.length) {
		// 		return res.status(422).json({
		// 			message: MESSAGE.post.custom("Please buy extra voting package for further process!!!")
		// 		});
		// 	}
		// }

		if (freeVoteAvailability) {
			return res.status(422).json({
				message: MESSAGE.post.custom("Please buy extra voting package for further process!!!")
			});
		}

		const newVote = new VoteModel({
			competition_object_id,
			round_object_id,
			participant_object_id,
			voter_object_id: user?._id,
			vote_earned: (!freeVoteAvailability) ? 1 : 0,
			voting_type: (!freeVoteAvailability) ? "FREE" : "PAID"
		});
		await newVote.save();
		return res.status(StatusCodes.CREATED).json({
			message: "Vote added successfully.",
			Result: newVote
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.post.fail,
			error
		});
	}
};
export const addVoteSubscription = async (req: Request, res: Response): Promise<any> => {
	try {
		const {
			competition_object_id,
			round_object_id,
			participant_object_id,
			number_of_votes,
			votes_price,
			transaction_id
		} = req.body;
		const user = await getDetailsByEmail(req.user.email);
		let stripePaymentIntent: any;
		if (user && user._id) {
			stripePaymentIntent = await createStripePaymentIntents(user._id.toString(),
				competition_object_id,
				votes_price,
				"DEBITED",
				"SUBSCRIPTION VOTE PACKAGE");
		}
		const stripePaymentDetails = stripePaymentIntent;
		if (!stripePaymentDetails) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: "Payment details not found."
			});
		}
		const newVote = new VotingSubscriptionModel({
			competition_object_id,
			round_object_id,
			participant_object_id,
			number_of_votes,
			votes_price,
			transaction_id: stripePaymentDetails?.id,
			stripe_payment_intant_id: stripePaymentDetails?.payment_data?.id,
			member_object_id: user?._id,
			stripe_payment_details: stripePaymentDetails
			// paymentStatus: "PAID",
		});
		await newVote.save();
		return res.status(StatusCodes.CREATED).json({
			message: "Vote package subscription successful.",
			Result: newVote
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.post.fail,
			error
		});
	}
};
export const veryfactionVoteSubscription = async (req: Request, res: Response): Promise<any> => {
	const { id } = req.params;
	const { paymentIntent_id } = req.body;
	// Validate paymentIntent_id
	if (!paymentIntent_id) {
		return res.status(StatusCodes.UNPROCESSABLE_ENTITY).json({
			status: false,
			message: "Stripe order Id is required",
			data: {}
		});
	}
	try {
		// Retrieve the existing vote subscription
		const existingVoteSubscription = await VotingSubscriptionModel.findById(id).lean();
		console.log("existingVoteSubscription====================", existingVoteSubscription);

		if (!existingVoteSubscription) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Vote subscription not found.",
				data: {}
			});
		}
		// Retrieve the Payment Intent from Stripe
		const paymentIntent = await verifyPaymentViaStripe(paymentIntent_id);
		if (paymentIntent && paymentIntent.status === "succeeded") {
			const paymentData = {
				paymentStatus: paymentIntent.status === "succeeded" ? PAYMENT_STATUS.paid : PAYMENT_STATUS.failed,
			};
			const updateVotesCount = await VoteModel.create({
				competition_object_id: existingVoteSubscription.competition_object_id,
				round_object_id: existingVoteSubscription.round_object_id,
				participant_object_id: existingVoteSubscription.participant_object_id,
				voter_object_id: existingVoteSubscription.member_object_id,
				vote_earned: existingVoteSubscription.number_of_votes,
				voting_type: "PAID",
			});
			console.log("updateVotesCount====================", updateVotesCount);
			// Update the vote subscription's payment status
			const updatedPayment = await VotingSubscriptionModel.findByIdAndUpdate(
				existingVoteSubscription._id,
				{ $set: paymentData },
				{ new: true, runValidators: true }
			);

			return res.status(StatusCodes.OK).json({
				message: MESSAGE.custom("Transaction fetched successfully!"),
				result: updatedPayment
			});
		} else {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Payment not successful!"),
				data: {}
			});
		}
	} catch (error) {
		console.error("Payment verification error:", error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: MESSAGE.custom("Transaction unsuccessful!"),
			error: error
		});
	}
};
// **************************Common ***********************************************************
export const getParticipantRoundStatuses = async (req: Request, res: Response): Promise<any> => {
	try {
		const userDetails = await getDetailsByEmail(req.user.email);
		if (!userDetails) {
			return res.status(StatusCodes.UNAUTHORIZED).json({ message: 'User not authenticated.' });
		}

		const statusFilter = req.params.status as 'upcoming' | 'ongoing' | 'completed' | undefined;
		const now = dayjs();

		// Fetch active participations
		const participants = await ParticipantModel.find({
			participant_object_id: userDetails._id,
			status: { $in: ['PARTICIPATING'] }
		})
			.populate({ path: 'competition_object_id' })
			.populate('participant_object_id')
			.populate('transaction_object_id')
			.lean();

		if (!participants.length) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: 'No active participations found.',
			});
		}

		// Use map for grouping competitions
		const competitionMap: Record<string, any> = {};

		for (const p of participants) {
			const comp = p.competition_object_id as any;
			if (!comp || !Array.isArray(comp?.rounds)) continue;

			for (const round of comp.rounds) {
				const start = dayjs(round.start_date_time);
				const end = dayjs(round.end_date_time);

				let roundStatus: 'upcoming' | 'ongoing' | 'completed';
				if (start.isAfter(now)) {
					roundStatus = 'upcoming';
				} else if (start.isBefore(now) && end.isAfter(now)) {
					roundStatus = 'ongoing';
				} else {
					roundStatus = 'completed';
				}

				// Apply API param filter
				if (statusFilter && roundStatus !== statusFilter) continue;

				// If competition not yet added → initialize it
				if (!competitionMap[comp._id]) {
					competitionMap[comp._id] = {
						competition: comp,
						participant: p,
						rounds_list: [], // collect rounds here
					};
				}

				// Push round into this competition’s rounds_list
				competitionMap[comp._id].rounds_list.push({
					...round,
					status: roundStatus,
				});
			}
		}

		const result = Object.values(competitionMap);

		if (result.length === 0) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: `No rounds found for status: ${statusFilter || 'all'}.`,
			});
		}

		return res.status(StatusCodes.OK).json({
			message: 'Participant round status fetched successfully',
			result,
		});

	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: "An error occurred while fetching participant round statuses.",
			error: error instanceof Error ? error.message : error,
		});
	}
};

export const getAllparticipantsList = async (req: Request, res: Response): Promise<any> => {
	try {
		const competitionId = req.params.competitionId;
		const roundId = req.params.roundId;
		if (!competitionId) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: 'Competition ID is required.'
			});
		}
		if (!roundId) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: 'Round ID is required.'
			});
		}
		// Fetch competition details with matching rounds
		const competition = await CompetitionModel.findById(competitionId)
			.populate({
				path: 'rounds',
				match: { _id: roundId }  // Filter rounds by roundId
			})
			.lean();
		if (!competition) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: 'Competition not found.'
			});
		}
		// Check if the rounds array contains the matched round
		const matchedRounds = competition.rounds.filter(round => round._id.toString() === roundId);
		if (matchedRounds.length === 0) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: 'No matching rounds found for this competition.'
			});
		}
		const roundsWithStatus = await Promise.all(matchedRounds.map(async (round) => ({
			...round,
			roundStatus: await get_round_status(dayjs(round.start_date_time), dayjs(round.end_date_time))
		})));
		// Fetch participants for the specific competition and round
		const participants = await ParticipantModel.find({
			competition_object_id: competitionId,
			round_object_id: roundId,
			status: { $in: [PARTICIPATION_STATUS.participating, PARTICIPATION_STATUS.participated] }, //PARTICIPATION_STATUS.participated,
			// status: { $in: [PARTICIPATION_STATUS.participating] }, //PARTICIPATION_STATUS.participated,
			participant_payment_status: { $eq: "SUCCESS" }
		})
			.populate('participant_object_id') // Populate participant details
			.lean();
		// Format the participant details
		const formattedParticipants = participants;
		// Return the competition details, matched rounds with status, and participants
		return res.status(StatusCodes.OK).json({
			message: 'Competition details with participants fetched successfully',
			competition: {
				_id: competition._id,
				name: competition.name,
				description: competition.description,
				rounds: roundsWithStatus,
				participants: formattedParticipants
			}
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: "An error occurred during the payment process.",
			error: error
		});
	}
};
export const getCompetitionDetailsWithRoundAndParticipants = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competitionId, roundId } = req.params;
		// Get user details
		const userDetails = await getDetailsByEmail(req.user.email);
		if (!userDetails) {
			return res.status(StatusCodes.UNAUTHORIZED).json({ message: "User not authenticated" });
		}
		// Validate input parameters
		if (!competitionId || !roundId) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: !competitionId ? 'Competition ID is required.' : 'Round ID is required.'
			});
		}
		const now = dayjs();
		// Fetch competition with filtered round
		const competition = await CompetitionModel.findById(competitionId)
			.populate({ path: 'rounds', match: { _id: roundId } })
			.lean();
		if (!competition || !competition.rounds?.length) {
			return res.status(StatusCodes.NOT_FOUND).json({ message: 'Competition or matching round not found.' });
		}
		const round = competition.rounds.find(r => r._id.toString() === roundId); // since we've matched by ID
		// Determine round status
		const roundStatus = get_round_status(round, now);
		const time_status = getTimeStatus(round, now);
		// Prepare rounds with status
		const roundsWithStatus = [{
			...round,
			roundStatus,
			time_status
		}];
		// Fetch participants
		const participants = await ParticipantModel.find({
			competition_object_id: competitionId,
			participant_object_id: userDetails._id.toString(),
			round_object_id: roundId,
			status: { $in: [PARTICIPATION_STATUS.participating] }, //PARTICIPATION_STATUS.participated,
			participant_payment_status: "SUCCESS"
		})
			.populate('participant_object_id')
			.populate('transaction_object_id')
			.lean();
		// Final result
		const result = {
			competition,
			current_rounds: roundsWithStatus,
			participants
		};
		return res.status(StatusCodes.OK).json({
			message: 'Competition details with participants fetched successfully',
			Result: result
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: "An error occurred during the payment process.",
			error: error
		});
	}
};
export const getParticipantTotalVotes = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competitionId, roundId, participantId } = req.params;
		if (!competitionId || !roundId) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: !competitionId ? 'Competition ID is required.' : 'Round ID is required.'
			});
		}
		const userDetails = await getDetailsByEmail(req.user.email);
		if (!userDetails) {
			return res.status(StatusCodes.UNAUTHORIZED).json({ message: "User not authenticated" });
		}
		// Fetch participant details
		const participant = await ParticipantModel.findOne({
			competition_object_id: competitionId.toString(),
			round_object_id: roundId.toString(),
			participant_object_id: participantId.toString(),
			// participant_object_id: userDetails._id.toString(),
			status: { $in: [PARTICIPATION_STATUS.participating, PARTICIPATION_STATUS.participated] }, //PARTICIPATION_STATUS.participated,
			participant_payment_status: "SUCCESS"
		})
			.populate('participant_object_id')
			.populate('transaction_object_id')
			.lean();
		if (!participant) {
			return res.status(StatusCodes.NOT_FOUND).json({ message: 'Participant not found.' });
		}
		// Fetch votes
		const votes = await VoteModel.find({
			competition_object_id: competitionId,
			round_object_id: roundId,
			participant_object_id: participantId,
			voting_type: { $in: ["FREE", "PAID"] }
		})
			.populate('voter_object_id')
			.populate('participant_object_id')
			.populate('competition_object_id')
			.lean();
		// voter_object_id: userDetails._id.toString(),
		const result = {
			totalVotes: votes.length,
			voters: votes
		};
		return res.status(StatusCodes.OK).json({
			message: 'Total votes fetched successfully',
			Result: result
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: "An error occurred while fetching participant votes.",
			error: error
		});
	}
}

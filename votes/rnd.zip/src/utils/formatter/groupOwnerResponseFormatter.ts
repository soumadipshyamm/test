import { IGroupOwnerResponse } from "../../@types/interfaces/formatter/groupOwner.interface";
import { IGroupOwner } from "../../@types/interfaces/groupOwnerSchema.interface";

export const formatGroupOwnerResponse = async (user: IGroupOwner): Promise<IGroupOwnerResponse> => {
	return {
		_id: user._id.toString(),
		role: user.role,
		first_name: user.first_name,
		middle_name: user.middle_name ?? null,
		last_name: user.last_name,
		email: user.email,
		user_name: user.user_name ?? null,
		gender: user.gender,
		phone_number: user.phone_number,
		phone_extension: user.phone_extension,
		address_line_1: user.address_line_1,
		address_line_2: user.address_line_2,
		city: user.city,
		state: user.state,
		zip: user.zip,
		country: user.country,
		contact_label: user.contact_label,
		is_registered: user.is_registered,
		is_active: user.is_active,
		is_disabled: user.is_disabled,
		feature_permission: user.feature_permission
	};
};

export const formatGroupOwnersResponse = async (users: IGroupOwner[]): Promise<IGroupOwnerResponse[]> => {
	const userResponses = await Promise.all(
		users.map(async (user) => {
			return {
				_id: user._id.toString(),
				role: user.role,
				first_name: user.first_name,
				middle_name: user.middle_name ?? null,
				last_name: user.last_name,
				email: user.email,
				user_name: user.user_name ?? null,
				gender: user.gender,
				phone_number: user.phone_number,
				phone_extension: user.phone_extension,
				address_line_1: user.address_line_1,
				address_line_2: user.address_line_2,
				city: user.city,
				state: user.state,
				zip: user.zip,
				country: user.country,
				contact_label: user.contact_label,
				is_registered: user.is_registered,
				is_active: user.is_active,
				is_disabled: user.is_disabled,
				feature_permission: user.feature_permission
			};
		})
	);

	return userResponses; // Return the array of user responses
};

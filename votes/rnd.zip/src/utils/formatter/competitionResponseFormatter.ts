import { ICompetitionResponse, ICompetitionDetails } from "../../@types/interfaces/formatter/competition.interface";
import { ICompetition } from "../../@types/interfaces/competition.interface";
import { formatParticipantResponse } from "./participantResponseFormatter";
import { formatCompetitionCreatorResponse } from "./competitionCreatorResponseFormatter";
import ParticipantModel from "../../model/participant.model";
import { IParticipant } from "../../@types/interfaces/participant.interface";
import { IMember } from "../../@types/interfaces/member.interface";
import { IGroupOwner } from "../../@types/interfaces/groupOwnerSchema.interface";
import MemberModel from "../../model/member.model";
import { ISavedCompetition } from "../../@types/interfaces/savedCompetition.interface";
import VoteModel from "../../model/vote.model";
import { Types } from 'mongoose';
import { log } from "console";
import { findCurrentRound } from "../helper";


export const formatCompetitionResponse = async (competition: ICompetition, user: IGroupOwner | IMember): Promise<ICompetitionDetails> => {

    const formattedRounds = await formatRounds(competition, user);
    const findCurrentRounds = await findCurrentRound(formattedRounds);
    // console.log("-------------------------------------------", findCurrentRounds);

    return {
        _id: competition._id.toString(),
        name: competition.name,
        description: competition.description,
        status: competition.status,
        prizes: competition.prizes,
        challenge_start_date: competition.challenge_start_date,
        challenge_end_date: competition.challenge_end_date,
        competition_type: competition.competition_type,
        no_of_rounds: competition.no_of_rounds,
        rounds: formattedRounds,
        current_round: findCurrentRounds?.round_no,
        feature_image: competition.feature_image,
        round_checkpoint_start_visibility: competition.round_checkpoint_start_visibility,
        no_of_winner: competition.no_of_winner,
        file_type: competition.file_type,
        created_by: competition.created_by,
        creator_company: competition.creator_company,
        creator_description: competition.creator_description
    };
};

// Function to format an array of competitions status wise
export const formatCompetitionsResponse = async (competitions: ICompetition[], user: IGroupOwner | IMember): Promise<ICompetitionResponse[]> => {
    const activeCompetitions: ICompetitionDetails[] = [];
    const pendingCompetitions: ICompetitionDetails[] = [];
    const rejectedCompetitions: ICompetitionDetails[] = [];
    const completedCompetitions: ICompetitionDetails[] = [];

    for (const competition of competitions) {
        const formattedRounds = await formatRounds(competition, user);
        const findCurrentRounds = await findCurrentRound(formattedRounds);
        const competitionDetails: ICompetitionDetails = {
            _id: competition._id.toString(),
            name: competition.name,
            description: competition.description,
            status: competition.status,
            prizes: competition.prizes,
            challenge_start_date: competition.challenge_start_date,
            challenge_end_date: competition.challenge_end_date,
            competition_type: competition.competition_type,
            no_of_rounds: competition.no_of_rounds,
            rounds: formattedRounds,
            current_round: findCurrentRounds?.round_no,
            feature_image: competition.feature_image,
            round_checkpoint_start_visibility: competition.round_checkpoint_start_visibility,
            no_of_winner: competition.no_of_winner,
            file_type: competition.file_type,
            created_by: competition.created_by,
            creator_company: competition.creator_company,
            creator_description: competition.creator_description,
        };

        switch (competition.status) {
            case "ACTIVE":
                activeCompetitions.push(competitionDetails);
                break;
            case "PENDING":
                pendingCompetitions.push(competitionDetails);
                break;
            case "REJECTED":
                rejectedCompetitions.push(competitionDetails);
                break;
            case "COMPLETED":
                completedCompetitions.push(competitionDetails);
                break;
            default:
                break;
        }
    }

    return [{
        active_competitions: activeCompetitions,
        pending_competitions: pendingCompetitions,
        rejected_competitions: rejectedCompetitions,
        completed_competitions: completedCompetitions,
    }];
};

// Function to format an array of competitions
export const formatAllCompetitionsResponse = async (competitions: ICompetition[], user: IGroupOwner | IMember): Promise<ICompetitionDetails[]> => {
    const competitionResponses = await Promise.all(
        competitions.map(async (competition) => {
            const formattedRounds = await formatRounds(competition, user);
            const findCurrentRounds = await findCurrentRound(formattedRounds);

            return {
                _id: competition._id.toString(),
                name: competition.name,
                description: competition.description,
                status: competition.status,
                prizes: competition.prizes,
                challenge_start_date: competition.challenge_start_date,
                challenge_end_date: competition.challenge_end_date,
                competition_type: competition.competition_type,
                no_of_rounds: competition.no_of_rounds,
                rounds: formattedRounds,
                current_round: findCurrentRounds?.round_no,
                feature_image: competition.feature_image,
                round_checkpoint_start_visibility: competition.round_checkpoint_start_visibility,
                no_of_winner: competition.no_of_winner,
                file_type: competition.file_type,
                created_by: competition.created_by,
                creator_company: competition.creator_company,
                creator_description: competition.creator_description,
            };
        })
    );

    return competitionResponses;
};
// Function to find participants by competition and round IDs
const findParticipantsByCompetitionAndRound = async (competitionId: string, roundId: string): Promise<IParticipant[]> => {
    try {
        const participants = await ParticipantModel.find({
            competition_object_id: competitionId,
            round_object_id: roundId
        });

        return participants;
    } catch (error) {
        console.error("Error fetching participants:", error);
        throw new Error("Could not fetch participants");
    }
};
// Function to find participants by competition and round IDs
const findParticipantsByCompetition = async (competitionId: string): Promise<IParticipant[]> => {
    try {
        const participants = await ParticipantModel.find({
            competition_object_id: competitionId
        });

        return participants;
    } catch (error) {
        console.error("Error fetching participants:", error);
        throw new Error("Could not fetch participants");
    }
};

const formatRounds = async (competition: ICompetition, user: IGroupOwner | IMember) => {
    return Promise.all(
        competition?.rounds?.map(async (round, index) => {
            const currentDateTime = new Date();
            const lastRoundEndDate = index > 0 ? competition.rounds[index - 1].end_date_time : null;
            const shouldEmptyParticipants = lastRoundEndDate && lastRoundEndDate >= currentDateTime;
            let formattedParticipants: any[] = [];
            let status = 'upcoming';
            if (round.start_date_time <= currentDateTime && round.end_date_time >= currentDateTime) {
                status = 'ongoing';
            } else if (round.end_date_time < currentDateTime) {
                status = 'completed';
            }
            if (!shouldEmptyParticipants) {
                const participants = await findParticipantsByCompetition(competition._id.toString());
                const userId = user ? user._id.toString() : null;

                const lastRoundParticipants = index > 0 ? await findParticipantsByCompetitionAndRound(competition._id.toString(), competition.rounds[index - 1]._id.toString()) : [];
                const wasParticipantLastRound = lastRoundParticipants.some(participant => participant.participant_object_id.toString() === userId);
                const currentRoundParticipants = await findParticipantsByCompetitionAndRound(competition._id.toString(), competition.rounds[index]._id.toString());
                const isParticipatingInCurrentRound = currentRoundParticipants.some(participant => participant.participant_object_id.toString() === userId);

                formattedParticipants = await Promise.all(
                    participants.map(async (participant) => {
                        const memberId = participant.participant_object_id;
                        const member: any = await MemberModel.findById(memberId).exec();
                        const isParticipant = isParticipatingInCurrentRound;
                        const isEliminated = wasParticipantLastRound && !isParticipant;

                        let memberDetails: any = await formatParticipantResponse(member);
                        memberDetails['is_participant'] = isParticipant;
                        memberDetails['is_eliminated'] = isEliminated;
                        memberDetails['content'] = currentRoundParticipants.find(participant => participant.participant_object_id.toString() === memberId.toString())?.content ?? null;

                        return memberDetails;
                    })
                );
            }

            return {
                ...round,
                status: status,
                participants: formattedParticipants
            };
        })
    );
};

// Function to format an array of competitions

export const formatParticipantCompetitionsResponse = async (competitions: ICompetition[], user: IGroupOwner | IMember, save_competitions: ISavedCompetition[]): Promise<ICompetitionDetails[]> => {
    const competitionResponses = await Promise.all(
        competitions.map(async (competition) => {
            const lastRoundWinner = competition.rounds[competition.rounds.length - 1].no_of_participant_proceeding;
            const lastRoundId = competition.rounds[competition.rounds.length - 1]._id.toString();
            const winners = await VoteModel.aggregate([
                {
                    $match: {
                        competition_object_id: new Types.ObjectId(competition._id),
                        round_object_id: new Types.ObjectId(lastRoundId)
                    }
                },
                {
                    $group: {
                        _id: "$participant_object_id",
                        vote_count: { $sum: 1 }
                    }
                },
                {
                    $sort: { vote_count: -1 }
                },
                {
                    $limit: lastRoundWinner
                },
                {
                    $lookup: {
                        from: "members",               // your collection name
                        localField: "_id",             // _id here is participant_object_id
                        foreignField: "_id",           // _id in members collection
                        as: "participant"
                    }
                },
                {
                    $unwind: "$participant"          // convert array to object
                },
                {
                    $project: {
                        _id: 0,
                        vote_count: 1,
                        participant: 1
                    }
                }
            ]);

            let winnersParticipants: any[] = [];

            if (winners.length > 0) {
                winnersParticipants = await Promise.all(
                    winners.map(async (winner) => {
                        const memberDetails = await formatParticipantResponse(winner.participant);
                        return {
                            ...memberDetails,
                            vote_count: winner.vote_count
                        };
                    })
                );
            }

            const formattedRounds = await formatRounds(competition, user);
            const findCurrentRounds = await findCurrentRound(formattedRounds);
            const isCompetitionSaved = save_competitions.some(value => value.competition_object_id.toString() === competition._id.toString());
            return {
                _id: competition._id.toString(),
                name: competition.name,
                description: competition.description,
                status: competition.status,
                prizes: competition.prizes,
                challenge_start_date: competition.challenge_start_date,
                challenge_end_date: competition.challenge_end_date,
                competition_type: competition.competition_type,
                no_of_rounds: competition.no_of_rounds,
                rounds: formattedRounds,
                current_round: findCurrentRounds?.round_no,
                feature_image: competition.feature_image,
                round_checkpoint_start_visibility: competition.round_checkpoint_start_visibility,
                no_of_winner: competition.no_of_winner,
                file_type: competition.file_type,
                created_by: competition.created_by,
                creator_company: competition.creator_company,
                creator_description: competition.creator_description,
                is_saved: isCompetitionSaved,
                winners: winnersParticipants
            };
        })
    );

    return competitionResponses;
};

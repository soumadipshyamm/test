import { model } from "mongoose";
import companyManagementSchema from "./schemaDefiniton/companyManagement.schema";
import { ICompanyManagement } from "../@types/interfaces/companyManagement.interface";

const CompanyManagementModel = model<ICompanyManagement>("company_managements", companyManagementSchema);

export default CompanyManagementModel;
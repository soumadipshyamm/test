import { model } from "mongoose";
import memberSchema from "./schemaDefiniton/member.schema";
import { IMember } from "../@types/interfaces/member.interface";

const MemberModel = model<IMember>("members", memberSchema);

export default MemberModel;
import { model } from "mongoose";
import { ISavedCompetition } from "../@types/interfaces/savedCompetition.interface";
import savedCompetitionSchema from "./schemaDefiniton/savedCompetition.schema";

const SavedCompetitionModel = model<ISavedCompetition>("saved_competitions", savedCompetitionSchema);

export default SavedCompetitionModel;
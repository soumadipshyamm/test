import { model } from "mongoose";
import { ICompetitionType } from "../@types/interfaces/competitionType.interface";
import competitionTypeSchema from "./schemaDefiniton/competitionType.schema";

const CompetitionTypeModel = model<ICompetitionType>("competition_types", competitionTypeSchema);

export default CompetitionTypeModel;
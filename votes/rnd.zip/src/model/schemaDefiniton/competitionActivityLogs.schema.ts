import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { ICompetition, Round, Prize } from "../../@types/interfaces/competition.interface";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { COMPETITION_STATUS, STATUS } from "../../constants/status/status";
import { ICompetitionActivityLog } from "../../@types/interfaces/competitionActivityLog.interface";

const roundSchema = new Schema<Round>({
	round_no: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
	},
	price: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
	},
	start_date_time: {
		...SCHEMA_DEFINITION_PROPERTY.requiredDate,
	},
	end_date_time: {
		...SCHEMA_DEFINITION_PROPERTY.requiredDate,
	},
	additional_vote_package: {
		type: Schema.Types.ObjectId,
		ref: 'VotePackage',
	},
	checkpoints: {
		...SCHEMA_DEFINITION_PROPERTY.requiredString,
	},
	free_voting_duration: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
	},
	no_of_participant_proceeding: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
	}
}, { _id: false });

const prizeSchema = new Schema<Prize>({
	name: {
		...SCHEMA_DEFINITION_PROPERTY.requiredString,
		trim: true,
		maxlength: [100, "Prize Name cannot be more than 100 characters"]
	},
	type: {
		type: String,
		enum: ['money', 'gift'],
		required: true,
	},
	value: {
		...SCHEMA_DEFINITION_PROPERTY.requiredString,
	}
}, { _id: false });

const competitionActivityLogSchema: Schema<ICompetitionActivityLog> = new Schema<ICompetitionActivityLog>(
	{
		name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [200, "Competition Name cannot be more than 100 characters"]
		},
		challenge_start_date: {
			...SCHEMA_DEFINITION_PROPERTY.requiredDate,
		},
		challenge_end_date: {
			...SCHEMA_DEFINITION_PROPERTY.requiredDate,
		},
		competition_type: {
			type: Schema.Types.ObjectId,
			ref: 'CompetitionType',
			required: true,
		},
		no_of_rounds: {
			...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
			min: 1,
		},
		rounds: [roundSchema],
		feature_image: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
		},
		description: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
		},
		round_checkpoint_start_visibility: {
			...SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
		},
		no_of_winner: {
			...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
			min: 1,
		},
		prizes: [prizeSchema],
		status: {
			type: String,
			enum: [COMPETITION_STATUS.active, COMPETITION_STATUS.pending, COMPETITION_STATUS.rejected, COMPETITION_STATUS.completed],
			default: 'PENDING',
		},
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default competitionActivityLogSchema;

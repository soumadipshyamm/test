import { Schema } from "mongoose";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { INotifaction } from "../../@types/interfaces/notifaction.interface";
import { NOTIFACTION_STATUS } from "../../constants/status/status";

const notifactionSchema: Schema<INotifaction> = new Schema<INotifaction>(
	{
		title: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			min: [0, "Wallet Widthdrawal Limit must be a positive number"], // Added minimum validation
		},
		message: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			min: [0, "Wallet Widthdrawal Limit must be a positive number"], // Added minimum validation
		},
		created_at: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			min: [0, "Wallet Widthdrawal Limit must be a positive number"], // Added minimum validation
		},
		status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [NOTIFACTION_STATUS.read, NOTIFACTION_STATUS.unread, NOTIFACTION_STATUS.all],
			default: NOTIFACTION_STATUS.unread // Default value set to unread
		},
		member_id: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
			ref: "members"
		},
		group_owner_id: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
			ref: "group_owners"
		},
	}
);

export default notifactionSchema;


import mongoose, { Schema } from 'mongoose';
import { IVotingSubscription } from '../../@types/interfaces/votingSubscription.interface';
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { PAYMENT_STATUS } from '../../constants/status/status';

const votingSubscriptionSchema = new Schema<IVotingSubscription>({
	competition_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: 'competitions',
		required: true,
	},
	participant_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: 'members',
		required: true,
	},
	round_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		required: true,
	},
	member_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: 'members',
		required: true,
	},
	number_of_votes: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber
	},
	votes_price: {
		...SCHEMA_DEFINITION_PROPERTY.requiredNumber
	},
	transaction_id: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
	},
	stripe_payment_intant_id: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
	},
	paymentStatus: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		enum: [PAYMENT_STATUS.pending, PAYMENT_STATUS.paid, PAYMENT_STATUS.unpaid, PAYMENT_STATUS.failed],
		default: PAYMENT_STATUS.pending
	},
	stripe_payment_details: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullObject
	},
}, {
	timestamps: true,
});

export default votingSubscriptionSchema;

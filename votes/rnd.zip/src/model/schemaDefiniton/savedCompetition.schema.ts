import { Schema } from "mongoose";
import { ISavedCompetition } from "../../@types/interfaces/savedCompetition.interface";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";

const savedCompetitionSchema: Schema<ISavedCompetition> = new Schema<ISavedCompetition>(
	{
		competition_object_id: {
			...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
			ref: 'competitions'
		},
		participant_object_id: {
			...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
			ref: 'members',
			required: true,
		},
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default savedCompetitionSchema;

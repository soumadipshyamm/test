import mongoose, { Schema } from 'mongoose';
import { IVote } from '../../@types/interfaces/vote.interface';
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { VOTINGTYPE } from '../../constants/votingType/votingType';

const voteSchema = new Schema<IVote>({
	competition_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: 'competitions',
		required: true,
	},
	participant_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: 'members',
		required: true,
	},
	round_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: 'rounds',
		required: true,
	},
	voter_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
		ref: 'members',
		required: true,
	},
	vote_subscription_object_id: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
		ref: 'voting_subscriptions',
	},
	vote_earned: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber
	},
	voting_type: {
		...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		enum: [VOTINGTYPE.free, VOTINGTYPE.paid]
	},
}, {
	timestamps: true,
});

export default voteSchema;

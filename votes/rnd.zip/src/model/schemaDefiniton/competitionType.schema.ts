import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { ICompetitionType } from "../../@types/interfaces/competitionType.interface";
import { STATUS } from "../../constants/status/status";

const competitionTypeSchema: Schema<ICompetitionType> = new Schema<ICompetitionType>(
	{
		competition_name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [100, "Competition Type Name cannot be more than 100 characters"]
		},
		competition_description: SCHEMA_DEFINITION_PROPERTY.requiredString,

		total_rounds: {
			...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
			min: 1,
		},
		status: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			enum: [STATUS.active, STATUS.inactive],
			default: STATUS.active
		},
		created_by: {
			type: Schema.Types.ObjectId,
			ref: 'members',
			required: true,
		},
		rounds_details: [
			{
				round_no: {
					...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
					min: 1,
				},
				price: {
					...SCHEMA_DEFINITION_PROPERTY.requiredNumber,
					default: 0,
				}
			}
		]
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default competitionTypeSchema;


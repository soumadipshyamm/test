import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { IMember } from "../../@types/interfaces/member.interface";
import { ROLES } from "../../constants/roles/roles";
import { GENDER } from "../../constants/gender/gender";
import { CONTACT_LABEL } from "../../constants/contactLabel/contactLabel";
import { COUNTRY } from "../../constants/country/employeeCountry";
import { MEMBER_STATUS, STATUS } from "../../constants/status/status";

const memberSchema: Schema<IMember> = new Schema<IMember>(
	{
		member_id: SCHEMA_DEFINITION_PROPERTY.optionalNullString, // Auto generated for workers and adminstrator member
		role: { ...SCHEMA_DEFINITION_PROPERTY.requiredString, enum: [ROLES.participant, ROLES.competition_creator, ROLES.individual_voter] },
		previous_role: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [ROLES.participant, ROLES.competition_creator, ROLES.individual_voter],
			default: null
		},
		first_name: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			trim: true,
			maxlength: [50, "First Name cannot be more than 50 characters"]
		},
		middle_name: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		last_name: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			trim: true,
			maxlength: [50, "First Name cannot be more than 50 characters"]
		},
		date_of_birth: SCHEMA_DEFINITION_PROPERTY.optionalNullDate,
		gender: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [GENDER.male, GENDER.female, GENDER.others, null]
		},
		otp: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		expiresAt: SCHEMA_DEFINITION_PROPERTY.optionalNullDate,
		phone_extension: SCHEMA_DEFINITION_PROPERTY.optionalNullNumber,
		phone_number: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber,
			minlength: [10, "Phone number must be at least 10 characters"],
			default: null
		},
		email: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			lowercase: true,
			unique: true,
		},
		user_name: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		password: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		address_line_1: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		address_line_2: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		city: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		state: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		zip: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		devices_token: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		is_registered: { ...SCHEMA_DEFINITION_PROPERTY.requiredBoolean, default: false },
		is_subscribe: SCHEMA_DEFINITION_PROPERTY.optionalBoolean,
		// self_details: {
		// 	...SCHEMA_DEFINITION_PROPERTY.optionalNullString

		// },
		is_approved: {
			// Default to true for members, false for competition creators for super admin  approval
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [MEMBER_STATUS.approved, MEMBER_STATUS.pending, MEMBER_STATUS.rejected, null]
		},
		country: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			default: COUNTRY
		},
		contact_label: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [
				CONTACT_LABEL.business,
				CONTACT_LABEL.home,
				CONTACT_LABEL.mail,
				CONTACT_LABEL.mobile,
				CONTACT_LABEL.other,
				null
			]
		},
		member_status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [STATUS.active, STATUS.inactive, null]
		},
		is_verified: {
			//for otp verification
			...SCHEMA_DEFINITION_PROPERTY.requiredBoolean,
			default: false
		},
		date: {
			...SCHEMA_DEFINITION_PROPERTY.requiredDate,
			default: Date.now
		},
		last_login_date: SCHEMA_DEFINITION_PROPERTY.optionalNullDate,
		upload_front_side: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullArray
		},
		upload_back_side: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullArray
		},
		discription: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString
		},
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default memberSchema;


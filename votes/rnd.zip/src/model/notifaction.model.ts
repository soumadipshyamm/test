import { model } from "mongoose";
import notifactionSchema from "./schemaDefiniton/notifaction.schema";
import { INotifaction } from "../@types/interfaces/notifaction.interface";

const notifactionModel = model<INotifaction>("notifaction", notifactionSchema);

export default notifactionModel;


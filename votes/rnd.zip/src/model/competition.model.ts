import { model } from "mongoose";
import { ICompetition } from "../@types/interfaces/competition.interface";
import competitionSchema from "./schemaDefiniton/competition.schema";

const CompetitionModel = model<ICompetition>("competitions", competitionSchema);

export default CompetitionModel;
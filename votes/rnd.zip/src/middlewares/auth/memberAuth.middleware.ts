import { Request, Response, NextFunction } from "express";
import { StatusCodes } from "http-status-codes";
import jwt from "jsonwebtoken";
import { MESSAGE } from "../../constants/message";
import { ROLES } from "../../constants/roles/roles";
import employeeModel from "../../model/member.model";

const memberAuth = async (req: Request, res: Response, next: NextFunction): Promise<any> => {
	try {
		if (!req.headers.authorization) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. No token provided")
			});
		}

		const token = req.headers.authorization.replace("Bearer ", "");

		if (!token) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. No token provided")
			});
		}

		if (!process.env.JWT_KEY) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Token not found")
			});
		}
		const decoded = jwt.verify(token, process.env.JWT_KEY) as Record<string, unknown>;

		if (!(decoded.role === ROLES.participant || ROLES.competition_creator || ROLES.individual_voter)) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. Invalid Token!"),
				token: req.header("token")
			});
		}

		req.user = decoded;
		req.user["read_access"] = false;
		req.user["write_access"] = false;

		if (req.user.role === ROLES.participant || ROLES.competition_creator || ROLES.individual_voter) {
			const { _id } = req.user;
			const employeeData = await employeeModel.findOne({
				$and: [{ _id }, { role: ROLES.participant || ROLES.competition_creator || ROLES.individual_voter }]
			});
			req.user.info = employeeData;
		}

		next();
	} catch (error) {
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.custom("Invalid Token!"),
			error: error,
			token: req.header("token")
		});
	}
};

export default memberAuth;


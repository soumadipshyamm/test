export type ContactLabel = "BUSINESS" | "HOME" | "MAIL" | "MOBILE" | "OTHER" | null;

export type groupOwnerRole = "SUPER ADMIN" | "ADMIN";

export type employeeRole = "EMPLOYEE";

export type memberRole = "COMPETITION CREATOR" | "PARTICIPANT" | "INDIVIDUAL VOTER";
// export type member_status = "approved" | "pending" | "rejected";
export type MEMBER_STATUS = {
	pending: "PENDING",
	approved: "APPROVED",
	rejected: "REJECTED"
}
export type prizesType = "money" | "gift" | "both";
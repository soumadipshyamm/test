export type VotingType = "FREE" | "Paid";

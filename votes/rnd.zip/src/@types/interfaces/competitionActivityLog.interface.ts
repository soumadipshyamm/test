import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface Round {
	round_no: number;
	price: number;
	start_date_time: Date;
	end_date_time: Date;
	additional_vote_package: IObjectId;
	checkpoints: string;
	free_voting_duration: number;
	no_of_participant_proceeding: number;
}

export interface Prize {
	name: string;
	type: 'money' | 'gift';
	value: string;
}

export interface CompetitionActivityLogSchema extends ICreated {
	name: string;
	challenge_start_date: Date;
	challenge_end_date: Date;
	competition_type: IObjectId;
	no_of_rounds: number;
	rounds: Round[];
	feature_image: string;
	description: string;
	round_checkpoint_start_visibility: boolean;
	no_of_winner: number;
	prizes: Prize[];
	status: 'PENDING' | 'ACTIVE' | 'REJECTED' | 'COMPLETED';
}

export interface ICompetitionActivityLog extends CompetitionActivityLogSchema, IObjectId { }

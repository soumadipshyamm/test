import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";
import { employeeRole, MEMBER_STATUS, memberRole } from "../types/role/roles.types";
import { Gender } from "../types/gender/gender.types";

export interface IMemberSchema extends ICreated {
	role: memberRole;
	previous_role: memberRole | null;
	member_id: string | null;
	first_name: string | null;
	middle_name: string | null;
	last_name: string | null;
	email: string; // Primary Key
	otp: string | null;
	expiresAt: Date | null;
	user_name: string | null;
	password: string | null;
	date_of_birth: SchemaDefinitionProperty<Date | null>;
	gender: Gender | null;
	phone_number: number | null;
	phone_extension: number | null;
	company: string | null;
	address_line_1: string | null;
	address_line_2: string | null;
	city: string | null;
	state: string | null;
	zip: string | null;
	// self_details: string | null;
	country: string | null;
	contact_label: string | null;
	member_status: string | null;
	is_verified: boolean | false;
	is_registered: boolean | false;
	is_subscribe: boolean | false;
	is_approved: string | null;
	devices_token: string | null;
	discription: string | null;
	date: SchemaDefinitionProperty<Date>;
	last_login_date: SchemaDefinitionProperty<Date | null>;
	upload_front_side: [
		{
			filename: String;
			path: String;
			size: Number;
		}
	];
	upload_back_side: [
		{
			filename: String;
			path: String;
			size: Number;
		}
	];
}
export interface IMember extends IMemberSchema, IObjectId { }

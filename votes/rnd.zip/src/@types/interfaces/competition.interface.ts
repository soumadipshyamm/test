import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface Round {
    _id: IObjectId
    round_no: number;
    price: number;
    start_date_time: Date;
    end_date_time: Date;
    additional_vote_package: IObjectId;
    checkpoints: string;
    free_voting_duration: number;
    no_of_participant_proceeding: number;
    status: string;
}

export interface Prize {
    name: string;
    type: string;
    value: string;
    description: string | null;
    money: number | null;
    gift: string | null;
}

export interface CompetitionSchema extends ICreated {
    name: string;
    challenge_start_date: Date;
    challenge_end_date: Date;
    competition_type: IObjectId;
    no_of_rounds: number;
    rounds: Round[];
    feature_image: string;
    description: string;
    round_checkpoint_start_visibility: boolean;
    no_of_winner: number;
    prizes: Prize[];
    status: string;
    file_type: string[];
    created_by: IObjectId;
    creator_company: IObjectId;
    creator_description: string;
    remarks: string | null;
}

export interface ICompetition extends CompetitionSchema, IObjectId { }

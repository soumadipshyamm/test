import { SchemaDefinitionProperty, Types } from "mongoose";
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface INotifactionSchema extends ICreated {
	title: string | null,
	message: string | null,
	created_at: string | null,
	status: string | null,
	member_id: Types.ObjectId | null
	group_owner_id: Types.ObjectId | null
}

export interface INotifaction extends INotifactionSchema, IObjectId { }

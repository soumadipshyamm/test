export const NODE_ENV: "PROD" | "DEV" | "LOCAL" | "LOCAL_ATLAS" = "LOCAL";

export const MONGO_URI = {
    LOCAL: "mongodb://127.0.0.1:27017/Voting_Platform_Portal",
    LOCAL_ATLAS: "",
    DEV: `mongodb://${process.env.DEV_MONGODB_USERNAME}:${process.env.DEV_MONGODB_PASSWORD}@${process.env.DEV_MONGODB_LOCALHOST}:${process.env.DEV_MONGODB_PORT}/${process.env.DEV_MONGODB_DATABASE_NAME}?authSource=${process.env.DEV_MONGODB_DATABASE_NAME}&directConnection=true`,
    PROD: `mongodb://${process.env.PROD_MONGODB_USERNAME}:${process.env.PROD_MONGODB_PASSWORD}@${process.env.PROD_MONGODB_LOCALHOST}:${process.env.PROD_MONGODB_PORT}/${process.env.PROD_MONGODB_DATABASE_NAME}?authSource=${process.env.PROD_MONGODB_DATABASE_NAME}&directConnection=true`
};

// Local, Devlopment and Production VotePleaseManagement Portal URL
export const localVotePleaseManagementUrl = "http://localhost:3000";
export const testVotePleaseManagementUrl = "";
export const devVotePleaseManagementUrl = "https://votesplease-frontend.shyamfuture.in/";
export const prodVotePleaseManagementUrl = "https://contestkingdom.com";

export const emailLoginUrl =
    String(NODE_ENV) == "PROD"
        ? `${prodVotePleaseManagementUrl}/`
        : String(NODE_ENV) == "DEV"
            ? `${devVotePleaseManagementUrl}/`
            : String(NODE_ENV) == "LOCAL"
                ? `${localVotePleaseManagementUrl}/`
                : ""; //Has to change in Production and Test Production

export const VOTES_PLEASE_MANAGEMENT_PORTAL_LINK = emailLoginUrl;

export const mongoDump = {
    host: String(NODE_ENV) == "PROD" ? "127.0.0.1" : "localhost",
    port: String(NODE_ENV) == "PROD" ? 27017 : 27017,
    database: "Votes_Please_Portal",
    outputDir: String(NODE_ENV) == "PROD" ? "" : __dirname + "../../../database_backup"
};

export const STRIPE_SECRET_KEY = "sk_test_51NdpkRBuHqQNZg72VM5ngF17FUi5lff7whLJdPy4IlFn6ZoymSeIvnOWVqB5NfaTHat6yHTCpJIPMCYHcp0HmxUm00I84mXZRh"
export const Backend_DEV_URL = "https://votesplease-backend.shyamfuture.in/"
export const Backend_PROD_URL = "https://backend.contestkingdom.com"
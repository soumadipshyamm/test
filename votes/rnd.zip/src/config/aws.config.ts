import { S3Client } from "@aws-sdk/client-s3";

const credential = {
	accessKeyId: "AKIA2A7LWBD7HKFL2KK3",
	secretAccessKey: "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",
};

export const s3Client = new S3Client({ region: "eu-north-1", credentials: credential });
export const s3Url = "https://soumadipagol.s3.eu-north-1.amazonaws.com"

export const bucketName = "soumadipagol";
export const bucketUrl = `https://${bucketName}.s3.eu-north-1.amazonaws.com`;

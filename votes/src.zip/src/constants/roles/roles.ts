export const roles = {
	super_admin: "SUPER ADMIN",
	admin: "ADMIN",
	member: "MEMBER",
	individual_voter: "INDIVIDUAL VOTER",
	participant: "PARTICIPANT",
	competition_creator: "COMPETITION CREATOR"
};

export const ROLES = roles;



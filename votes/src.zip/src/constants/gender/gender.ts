export const GENDER = {
	male: "MALE",
	female: "FEMALE",
	others: "OTHERS"
};

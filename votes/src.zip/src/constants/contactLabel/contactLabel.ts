export const CONTACT_LABEL = {
	business: "BUSINESS",
	home: "HOME",
	mail: "MAIL",
	mobile: "MOBILE",
	other: "OTHER"
};

import { model } from "mongoose";
import { IMemberLog } from "../@types/interfaces/memberLog.interface";
import memberLogSchema from "./schemaDefiniton/memberLog.schema";

const memberLogModel = model<IMemberLog>("member_logs", memberLogSchema);

export default memberLogModel;

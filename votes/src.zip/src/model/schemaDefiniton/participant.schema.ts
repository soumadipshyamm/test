import { Schema } from "mongoose";
import { IParticipant } from "../../@types/interfaces/participant.interface";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { PARTICIPATION_STATUS, TRANSACTION_STATUS } from "../../constants/status/status";

const participantSchema = new Schema<IParticipant>(
	{
		competition_object_id: {
			...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
			ref: 'competitions'
		},
		participant_object_id: {
			...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
			ref: 'members'
		},
		round_object_id: {
			...SCHEMA_DEFINITION_PROPERTY.requiredObjectId
		},
		competition_name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
		},
		round_no: {
			...SCHEMA_DEFINITION_PROPERTY.requiredNumber
		},
		participant_name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
		},
		participant_payment_type: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString
		},
		participant_payment_status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [TRANSACTION_STATUS.success, TRANSACTION_STATUS.cancel, TRANSACTION_STATUS.pending],
			default: TRANSACTION_STATUS.pending,
		},
		participant_payment_intant_id: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString
		},
		transaction_object_id: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
			ref: 'transactions'
		},
		content: {
			description: {
				...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
				trim: true,
			},
			upload_date_time: {
				...SCHEMA_DEFINITION_PROPERTY.optionalNullDate
			},
			files: [{
				url: {
					...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
					required: true,
				},
				name: {
					...SCHEMA_DEFINITION_PROPERTY.requiredString,
					required: true,
				}
			}],
		},
		thumbnail_url: {
			files: [{
				url: {
					...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
				},
				name: {
					...SCHEMA_DEFINITION_PROPERTY.requiredString,
				}
			}],
		},
		status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [PARTICIPATION_STATUS.participated, PARTICIPATION_STATUS.participating, PARTICIPATION_STATUS.eliminated, PARTICIPATION_STATUS.winner],
			default: PARTICIPATION_STATUS.participating,
		},
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default participantSchema;

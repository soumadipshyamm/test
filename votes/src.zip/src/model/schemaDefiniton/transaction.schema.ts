import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { TRANSACTION_STATUS, TRANSACTION_TYPE } from "../../constants/status/status";
import { ITransaction } from "../../@types/interfaces/transaction.interface";

const ITransactionSchema: Schema<ITransaction> = new Schema<ITransaction>(
	{
		payment_intent_id: SCHEMA_DEFINITION_PROPERTY.requiredString, // Auto generated for workers and adminstrator member
		member_objectId: {
			...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
			ref: "members"
		},
		competition_objectId: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullObjectId,
			ref: "competitions"
		},
		type: SCHEMA_DEFINITION_PROPERTY.requiredString,
		payment_type: SCHEMA_DEFINITION_PROPERTY.requiredString,
		payment_status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [TRANSACTION_STATUS.pending, TRANSACTION_STATUS.cancel, TRANSACTION_STATUS.success, null],
			default: TRANSACTION_STATUS.pending
		},
		// payment_status: SCHEMA_DEFINITION_PROPERTY.requiredString,
		amount: SCHEMA_DEFINITION_PROPERTY.requiredNumber,
		transaction_status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [TRANSACTION_TYPE.credited, TRANSACTION_TYPE.debited, null]
			// default: TRANSACTION_STATUS.pending
		},
		transaction_date: SCHEMA_DEFINITION_PROPERTY.requiredString,
		message: SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		payment_data: SCHEMA_DEFINITION_PROPERTY.optionalNullObject,
		respons_data: SCHEMA_DEFINITION_PROPERTY.optionalNullObject
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default ITransactionSchema;

import { Schema, STATES } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { ROLES } from "../../constants/roles/roles";
import { GENDER } from "../../constants/gender/gender";
import { STATUS } from "../../constants/status/status";
import { CONTACT_LABEL } from "../../constants/contactLabel/contactLabel";
import { COUNTRY } from "../../constants/country/employeeCountry";
import { ICompetitionType } from "../../@types/interfaces/competitionType.interface";
import { IVotePackage } from "../../@types/interfaces/votePackage.interface";

const votePackageSchema: Schema<IVotePackage> = new Schema<IVotePackage>(
	{
		package_name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [100, "Competition Name cannot be more than 100 characters"]
		},
		package_type: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			default: null
		},
		votes_package: [
			{
				number_of_votes: {
					...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber
				},
				votes_price: {
					...SCHEMA_DEFINITION_PROPERTY.optionalNullNumber
				},
				status: {
					...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
					enum: [STATUS.active, STATUS.inactive],
					default: STATUS.active
				},
			}
		],
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default votePackageSchema;


import { Schema } from "mongoose";
import { GENERAL_SCHEMA_OPTIONS } from "../../constants/model/schemaOption";
import { ICompetition, Round, Prize } from "../../@types/interfaces/competition.interface";
import SCHEMA_DEFINITION_PROPERTY from "../../constants/model/model.constant";
import { COMPETITION_STATUS, STATUS } from "../../constants/status/status";
import { ICompanyManagement } from "../../@types/interfaces/companyManagement.interface";



const companyManagementSchema: Schema<ICompanyManagement> = new Schema<ICompanyManagement>(
	{
		name: {
			...SCHEMA_DEFINITION_PROPERTY.requiredString,
			trim: true,
			maxlength: [200, "Competition Name cannot be more than 100 characters"]
		},
		description: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
		},
		status: {
			...SCHEMA_DEFINITION_PROPERTY.optionalNullString,
			enum: [COMPETITION_STATUS.active, COMPETITION_STATUS.pending, COMPETITION_STATUS.rejected, COMPETITION_STATUS.completed],
			default: 'PENDING',
		},
		member_object_id: {
			...SCHEMA_DEFINITION_PROPERTY.requiredObjectId,
			ref: "members",
			required: true
		}
	},
	{
		...GENERAL_SCHEMA_OPTIONS,
		toJSON: { virtuals: true },
		toObject: { virtuals: true }
	}
);

export default companyManagementSchema;

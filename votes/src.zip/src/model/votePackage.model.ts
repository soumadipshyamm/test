import { model } from "mongoose";
import memberSchema from "./schemaDefiniton/member.schema";
import { ICompetitionType } from "../@types/interfaces/competitionType.interface";
import competitionTypeSchema from "./schemaDefiniton/competitionType.schema";
import votePackageSchema from "./schemaDefiniton/votePackage.schema";
import { IVotePackage } from "../@types/interfaces/votePackage.interface";

const VotePackageModel = model<IVotePackage>("vote_packages", votePackageSchema);

export default VotePackageModel;
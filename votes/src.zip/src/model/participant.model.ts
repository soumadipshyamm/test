import { model } from "mongoose";
import { IParticipant } from "../@types/interfaces/participant.interface";
import participantSchema from "./schemaDefiniton/participant.schema";

const ParticipantModel = model<IParticipant>("participants", participantSchema);

export default ParticipantModel;
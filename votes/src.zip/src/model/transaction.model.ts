import { model } from "mongoose";
import ITransactionSchema from "./schemaDefiniton/transaction.schema";
import { ITransaction } from "../@types/interfaces/transaction.interface";

const transactionModel = model<ITransaction>("transactions", ITransactionSchema);

export default transactionModel;

import { model } from "mongoose";
import votingSubscriptionSchema from "./schemaDefiniton/votingSubscription.schema";
import { IVotingSubscription } from "../@types/interfaces/votingSubscription.interface";

const VotingSubscriptionModel = model<IVotingSubscription>("voting_subscriptions", votingSubscriptionSchema);

export default VotingSubscriptionModel;
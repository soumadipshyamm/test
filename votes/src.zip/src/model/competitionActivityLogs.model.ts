import { model } from "mongoose";
import { ICompetition } from "../@types/interfaces/competition.interface";
import competitionSchema from "./schemaDefiniton/competition.schema";
import competitionActivityLogSchema from "./schemaDefiniton/competitionActivityLogs.schema";

// const CompetitionActivityLogsModel = model<ICompetition>("competition_activity_logs", competitionActivityLogSchema);

// export default CompetitionActivityLogsModel;
;
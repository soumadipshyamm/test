import { model } from "mongoose";
import voteSchema from "./schemaDefiniton/vote.schema";
import { IVote } from "../@types/interfaces/vote.interface";

const VoteModel = model<IVote>("votes", voteSchema);

export default VoteModel;
import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface votingSubscriptionSchema extends ICreated {
	competition_object_id: IObjectId;
	participant_object_id: IObjectId;
	round_object_id: IObjectId;
	member_object_id: IObjectId;
	number_of_votes: Number;
	votes_price: Number;
	transaction_id: string;
	stripe_payment_intant_id: string | null;
	paymentStatus: string;
	stripe_payment_details?: object | null;
}
export interface IVotingSubscription extends votingSubscriptionSchema, IObjectId { }
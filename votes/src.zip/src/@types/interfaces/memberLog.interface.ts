import { SchemaDefinitionProperty } from "mongoose";
import { IObjectId } from "./objectId.interface";

export interface IMemberLogSchema {
	role: string;
	email: string;
	first_name: string;
	middle_name: string | null;
	last_name: string;
	user_name: string;
	activity: string;
	status: string;
	description: string;
	activity_initiated_by: string | null;
	date: SchemaDefinitionProperty<Date | null>;
	time: SchemaDefinitionProperty<Date>;
}

export interface IMemberLog extends IMemberLogSchema, IObjectId { }

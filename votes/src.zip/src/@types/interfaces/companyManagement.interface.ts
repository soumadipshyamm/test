import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";



export interface CompanyManagementSchema extends ICreated {
	name: string;
	description: string;
	member_object_id: IObjectId;
	status: 'PENDING' | 'ACTIVE' | 'REJECTED' | 'COMPLETED';
}

export interface ICompanyManagement extends CompanyManagementSchema, IObjectId { }

import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";


export interface SavedCompetitionSchema extends ICreated {
	competition_object_id: IObjectId;
	participant_object_id: IObjectId;
}

export interface ISavedCompetition extends SavedCompetitionSchema, IObjectId { }

import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface votePackageSchema extends ICreated {
	package_name: string | null;
	package_type: string | null;
	votes_package: [
		{
			number_of_votes?: number | null;
			votes_price?: number | null;
		}
	]
}

export interface IVotePackage extends votePackageSchema, IObjectId { }

import { IObjectId } from "../objectId.interface";
import { ICreated } from "../general.interface";

export interface Content {
    description: string;
    upload_date_time: string;
    files: Array<{
        url: string;
        name: string;
    }>;
}

export interface ParticipantSchema extends ICreated {
    competition_object_id: IObjectId;
    participant_object_id: IObjectId;
    round_object_id: IObjectId;
    competition_name: string;
    round_no: number;
    participant_name: string;
    content: Content;
    status: string;
    participant_payment_type: string;
    participant_payment_status: string;
    participant_payment_intant_id: string;
    transaction_object_id: IObjectId | null;
    thumbnail_url: string | null;
}

export interface IParticipant extends ParticipantSchema, IObjectId { }

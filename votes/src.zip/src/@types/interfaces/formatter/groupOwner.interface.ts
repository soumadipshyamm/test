import { Schema } from "mongoose";
import { ContactLabel } from "../../types/contactLabel/contactLabel.types";
import { Gender } from "../../types/gender/gender.types";
import { groupOwnerRole } from "../../types/role/roles.types";

export interface IGroupOwnerResponse {
	_id: Schema.Types.ObjectId | string;
	first_name: string;
	middle_name: string | null;
	last_name: string;
	user_name: string | null;
	role: groupOwnerRole;
	email: string;
	gender: Gender;
	address_line_1: string | null;
	address_line_2: string | null;
	city: string | null;
	state: string | null;
	country: string | null;
	zip: string | null;
	contact_label: ContactLabel;
	phone_number: number | null;
	phone_extension: number | null;
	is_registered: boolean;
	is_active: boolean;
	is_disabled: boolean;
	feature_permission: {
		user_management: {
			admin: boolean;
			competition_creater: boolean;
			participant: boolean;
			voter: boolean;
		};
		competition_management: {
			competition_type: boolean;
			all_competition: boolean;
			competition_result: boolean;
		};
		vote_package_management: boolean;
		revenue_management: boolean;
		reports: boolean;
	};
}

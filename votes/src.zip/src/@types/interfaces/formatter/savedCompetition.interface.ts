import { SchemaDefinitionProperty, Schema } from "mongoose";
import { IObjectId } from "../objectId.interface";

export interface ISavedCompetitionResponse {
	_id: Schema.Types.ObjectId | string;
	competition_object_id: IObjectId;
	participant_object_id: IObjectId;
}


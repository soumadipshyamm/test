import { Schema } from "mongoose";
import { IMember } from "../member.interface";
import { IObjectId } from "../objectId.interface";

export interface Round {
	round_no: number;
	price: number;
	start_date_time: Date;
	end_date_time: Date;
	additional_vote_package: IObjectId;
	checkpoints: string;
	free_voting_duration: number;
	no_of_participant_proceeding: number;
	participants: Object[];
	status: string;
}

export interface Prize {
	name: string;
	type: string;
	value: string;
}

export interface ICompetitionDetails {
	_id: Schema.Types.ObjectId | string;
	name: string;
	description: string;
	status: string;
	challenge_start_date: Date;
	challenge_end_date: Date;
	competition_type: IObjectId;
	no_of_rounds: number;
	rounds: Round[] | null;
	feature_image: string;
	round_checkpoint_start_visibility: boolean;
	no_of_winner: number;
	current_round: number | '',
	prizes: Prize[];
	file_type: string[];
	created_by: Object;
	creator_company: IObjectId;
	creator_description: string;
}

export interface ICompetitionResponse {
	active_competitions: ICompetitionDetails[];
	pending_competitions: ICompetitionDetails[];
	rejected_competitions: ICompetitionDetails[];
	completed_competitions: ICompetitionDetails[];
}

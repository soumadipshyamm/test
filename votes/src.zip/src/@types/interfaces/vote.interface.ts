import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";
import { VotingType } from "../types/votingType/votingType.types";

export interface voteSchema extends ICreated {
    competition_object_id: IObjectId;
    participant_object_id: IObjectId;
    round_object_id: IObjectId;
    voter_object_id: IObjectId;
    vote_subscription_object_id: IObjectId | null;
    voting_type: VotingType;
    vote_earned: number | null;
}


export interface IVote extends voteSchema, IObjectId { }
import { ObjectId, SchemaDefinitionProperty, Types } from "mongoose";
import { ContactLabel } from "../types/contactLabel/contactLabel.types";
import { Gender } from "../types/gender/gender.types";
import { groupOwnerRole } from "../types/role/roles.types";
import { ICreated } from "./general.interface";
import { IObjectId } from "./objectId.interface";
import { MaritalStatus } from "../types/maritalStatus/maritalStatus.types";

export interface IGroupOwnerSchema extends ICreated {
	first_name: string;
	middle_name: string | null;
	last_name: string;
	user_name: string | null;
	password: string | null;
	role: groupOwnerRole;
	email: string;
	gender: Gender;
	address_line_1: string | null;
	address_line_2: string | null;
	city: string | null;
	state: string | null;
	country: string | null;
	zip: string | null;
	// ZIP: string | null;
	contact_label: ContactLabel;
	phone_number: number | null;
	phone_extension: number | null;
	is_registered: boolean; // This field is for checking whether the user is registered or not.
	is_active: boolean; // This field is for chat support, that whether the user is online or not.
	is_disabled: boolean; // This field is to disable Group Owners from accessing their Profile (i.e if is_disabled = true, then particular owner will not able to login)
	devices_token: string | null;
	feature_permission: {
		user_management: {
			admin: boolean;
			competition_creater: boolean;
			participant: boolean;
			voter: boolean;
		};
		competition_management: {
			competition_type: boolean;
			all_competition: boolean;
			competition_result: boolean;
		};
		vote_package_management: boolean;
		revenue_management: boolean;
		reports: boolean;
	};
	otp: string | null,
	expiresAt: Date | null,
	last_login_date: SchemaDefinitionProperty<Date | null>;
}

export interface IGroupOwner extends IGroupOwnerSchema, IObjectId { }

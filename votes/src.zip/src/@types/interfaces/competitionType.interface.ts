import { ICreated } from "../general.interface";
import { IObjectId } from "../objectId.interface";

export interface competitionTypeSchema extends ICreated {
	competition_name: string | null;
	competition_description: string | null;
	total_rounds: number | null;
	status: string | null;
	rounds_details: RoundDetails[];
	created_by: string | null;
}

export interface RoundDetails {
	round_no: number | null;
	price: number | null;
}
export interface ICompetitionType extends competitionTypeSchema, IObjectId { }


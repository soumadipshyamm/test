export type Receipents = string;

export type ReceipentsMailObject = {
	to: string;
	html: string;
};

export type SchedulerMailReceipents = {
	[key in Receipents]: ReceipentsMailObject;
};

export interface IEmailObject extends ReceipentsMailObject {
	subject: string;
}

export type EmailAttachment = {
	filename: string;
	content: string;
};

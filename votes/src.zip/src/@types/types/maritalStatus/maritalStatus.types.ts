export type MaritalStatus = "SINGLE" | "MARRIED" | "DIVORCED" | "COMMON LAW MARRIAGE" | null;

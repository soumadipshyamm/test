import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../constants/message";
import GroupOwnerModel from "../../model/groupOwner.model";
import { ROLES } from "../../constants/roles/roles";

const groupOwnerAuth = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
	try {
		if (!req.headers.authorization) {
			res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. No token provided"),
			});
			return; // End the function after sending the response
		}

		const token = req.headers.authorization.replace("Bearer ", "");
		if (!token) {
			res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. No token provided"),
			});
			return; // End the function after sending the response
		}

		if (!process.env.JWT_KEY) {
			res.status(StatusCodes.BAD_REQUEST).json({
				message: MESSAGE.custom("Token not found"),
			});
			return; // End the function after sending the response
		}

		const decoded = jwt.verify(token, process.env.JWT_KEY) as Record<string, unknown>;
		if (!(decoded.role === ROLES.super_admin || decoded.role === ROLES.admin)) {
			res.status(StatusCodes.UNAUTHORIZED).json({
				message: MESSAGE.custom("Access denied. Invalid Token!"),
				token: req.header("token"),
			});
			return; // End the function after sending the response
		}

		req.user = decoded;

		req.user["read_access"] = false;
		req.user["write_access"] = false;

		if (req.user.role === ROLES.super_admin) {
			const { _id } = req.user;
			req.user.write_access = req.user.read_access = true;
			const data = await GroupOwnerModel.findOne({
				$and: [{ _id }, { role: ROLES.super_admin }],
			});
			req.user.info = data;
		} else if (req.user.role === ROLES.admin) {
			const { _id } = req.user;
			const data = await GroupOwnerModel.findOne({
				$and: [{ _id }, { role: ROLES.admin }],
			});
			req.user.info = data;
		}

		next(); // Call next() to proceed to the next middleware or route handler
	} catch (error) {
		res.status(400).json({
			message: MESSAGE.custom("Invalid Token!"),
			error: error,
			token: req.header("token"),
		});
	}
};

export default groupOwnerAuth;

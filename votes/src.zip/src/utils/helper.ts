import GroupOwnerModel from "../model/groupOwner.model";
import MemberModel from "../model/member.model";
import { IMember } from "../@types/interfaces/member.interface";
import { IGroupOwner } from "../@types/interfaces/groupOwnerSchema.interface";
import CompetitionModel from "../model/competition.model";
import dayjs from "dayjs";
import VoteModel from "../model/vote.model";
import mongoose, { ObjectId } from 'mongoose';
import { cache } from "joi";

type User = IGroupOwner | IMember | null;
export type RoundStatus = 'upcoming' | 'ongoing' | 'completed';

export const getDetailsByEmail = async (email: string): Promise<User> => {
    try {
        let user: User | null = await GroupOwnerModel.findOne({ email });
        if (!user) {
            user = await MemberModel.findOne({ email });
        }
        return user;
    } catch (error) {
        return null;
    }
};
export const capitalizeString = async (inputString: string): Promise<string | null> => {
    if (!inputString) return '';
    return inputString.charAt(0).toUpperCase() + inputString.slice(1).toLowerCase();
}
export const getRoundStatus = async (
    startDateTime: Date,
    endDateTime: Date
) => {
    // console.log(`Start Date: ${startDateTime}, End Date: ${endDateTime}`);

    if (!startDateTime || !endDateTime) {
        return "Invalid dates"; // Handle invalid date inputs
    }

    let status = "upcoming"; // Default status
    const currentDateTime = new Date();
    if (startDateTime <= currentDateTime && endDateTime >= currentDateTime) {
        status = "ongoing"; // The round is currently ongoing
    } else if (endDateTime < currentDateTime) {
        status = "completed"; // The round has already completed
    }

    return status; // Return the determined status
};
export const findCurrentRound = async (rounds: Array<{ status: string }>): Promise<string | any> => {
    const currentRound = rounds.find(round =>
        round.status === "ongoing" || round.status === "upcoming"
    );
    return currentRound; // Return null if no round is found
};
// export const calculateDuration = (startDate: Date): string => {

//     const timeUntil = dayjs(startDate).diff(dayjs(), 'millisecond');
//     const durationObj = dayjs.duration(timeUntil);
//     return `Starts in ${durationObj.days()}d ${durationObj.hours()}h ${durationObj.minutes()}m`;
// };
// export const currentRound = async (competitionId: string, res: any): Promise<any> => {
//     try {
//         console.log("Fetching current round for competition ID*******:", competitionId);

//         const competition = await CompetitionModel.findById(competitionId);

//         if (!competition || !competition.rounds || competition.rounds.length === 0) {
//             return res.status(404).json({ message: "No rounds found" });
//         }
//         console.log("competition-----------", competition);
//         const now = new Date();
//         // Check if the competition is completed
//         if (now >= competition.challenge_end_date) {
//             const completedRounds = competition.rounds.filter(r => r.end_date_time <= competition.challenge_end_date);
//             if (completedRounds.length > 0) {
//                 const lastCompletedRound = completedRounds[completedRounds.length - 1]; // Get the last completed round
//                 return ({
//                     status: "completed",
//                     time_status: "Completed",
//                     round_no: lastCompletedRound.round_no,
//                     price: lastCompletedRound.price,
//                     start_date_time: lastCompletedRound.start_date_time,
//                     end_date_time: lastCompletedRound.end_date_time,
//                     free_voting_duration: lastCompletedRound.free_voting_duration,
//                     no_of_participant_proceeding: lastCompletedRound.no_of_participant_proceeding,
//                     additional_vote_package: lastCompletedRound.additional_vote_package,
//                     checkpoints: lastCompletedRound.checkpoints,
//                     _id: lastCompletedRound._id
//                 });
//             }
//         }
//         // Try to find ongoing round
//         const ongoingRound = competition.rounds.find(r => {
//             const start = new Date(r.start_date_time);
//             const end = new Date(r.end_date_time);
//             return start <= now && now <= end;
//         });
//         if (ongoingRound) {
//             return ({
//                 status: "ongoing",
//                 time_status: "Ongoing now",
//                 round_no: ongoingRound.round_no,
//                 price: ongoingRound.price,
//                 start_date_time: ongoingRound.start_date_time,
//                 end_date_time: ongoingRound.end_date_time,
//                 free_voting_duration: ongoingRound.free_voting_duration,
//                 no_of_participant_proceeding: ongoingRound.no_of_participant_proceeding,
//                 additional_vote_package: ongoingRound.additional_vote_package,
//                 checkpoints: ongoingRound.checkpoints,
//                 _id: ongoingRound._id
//             });
//         }
//         // If no ongoing, find nearest upcoming
//         const upcomingRounds = competition.rounds
//             .filter(r => new Date(r.start_date_time) > now)
//             .sort((a, b) => new Date(a.start_date_time).getTime() - new Date(b.start_date_time).getTime());
//         if (upcomingRounds.length === 0) {
//             return res.status(404).json({ message: "No upcoming rounds available" });
//         }
//         const upcomingRound = upcomingRounds[0];
//         const timeStatus = calculateDuration(new Date(upcomingRound.start_date_time)); // Convert to Date
//         return {
//             status: "upcoming",
//             time_status: timeStatus,
//             round_no: upcomingRound.round_no,
//             price: upcomingRound.price, // Assuming price is a field in the round object
//             start_date_time: upcomingRound.start_date_time,
//             end_date_time: upcomingRound.end_date_time,
//             free_voting_duration: upcomingRound.free_voting_duration,
//             no_of_participant_proceeding: upcomingRound.no_of_participant_proceeding,
//             additional_vote_package: upcomingRound.additional_vote_package,
//             checkpoints: upcomingRound.checkpoints,
//             _id: upcomingRound._id
//         };
//     } catch (error) {
//         console.error("Error determining current/upcoming round:", error);
//         return res.status(500).json({ message: "Internal server error" });
//     }
// };
export const get_round_status = (round: any, now: dayjs.Dayjs): "ongoing" | "upcoming" | "completed" => {
    if (dayjs(round.start_date_time).isBefore(now) && dayjs(round.end_date_time).isAfter(now)) {
        return "ongoing";
    } else if (dayjs(round.start_date_time).isAfter(now)) {
        return "upcoming";
    }
    return "completed";
};
export const getTimeStatus = (round: any, now: dayjs.Dayjs): string => {
    const startTime = dayjs(round.start_date_time);
    const endTime = dayjs(round.end_date_time);

    if (now.isBefore(startTime)) {
        const dur = dayjs.duration(startTime.diff(now));
        return `Starts in ${dur.days()}d ${dur.hours()}h ${dur.minutes()}m`;
    } else if (now.isAfter(endTime)) {
        return 'Ended';
    } else {
        const dur = dayjs.duration(endTime.diff(now));
        return `Live - Ends in ${dur.days()}d ${dur.hours()}h ${dur.minutes()}m`;
    }
};
export const getFileExtension = (mimeType: string) => {
    const mimeToExt: { [key: string]: string } = {
        'image/jpeg': 'jpeg',
        'image/jpg': 'jpg',
        'image/png': 'png',
        'image/gif': 'gif',
        'image/webp': 'webp',
        'application/pdf': 'pdf',
        'application/msword': 'doc',
        //videos and audio 
        'video/mp4': 'mp4',
        'audio/mpeg': 'mp3',
        'audio/ogg': 'ogg',
        'audio/wav': 'wav',
        'audio/webm': 'webm'

    };
    return mimeToExt[mimeType];
};

// export const calculateDurations = (startDate: Date): string => {
//     const now = new Date();
//     const diffMs = startDate.getTime() - now.getTime();
//     const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
//     const diffHours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));

//     if (diffDays > 0) {
//         return `Starts in ${diffDays} day(s)`;
//     } else if (diffHours > 0) {
//         return `Starts in ${diffHours} hour(s)`;
//     }
//     return "Starting soon";
// };


// export const currentRounds = async (competitionId: string): Promise<any | null> => {
//     try {
//         console.log("Fetching current round for competition ID:", competitionId);

//         const competition = await CompetitionModel.findById(competitionId).lean();

//         if (!competition || !competition.rounds || competition.rounds.length === 0) {
//             console.warn(`No competition or rounds found for ID: ${competitionId}`);
//             return null;
//         }

//         const now = new Date();

//         // 1. Check if competition is completed
//         if (now >= new Date(competition.challenge_end_date)) {
//             const completedRounds = competition.rounds
//                 .filter((r: any) => new Date(r.end_date_time) <= new Date(competition.challenge_end_date))
//                 .sort((a: any, b: any) => new Date(b.end_date_time).getTime() - new Date(a.end_date_time).getTime());

//             if (completedRounds.length > 0) {
//                 const lastRound = completedRounds[0];
//                 return {
//                     ...lastRound,
//                     status: "completed",
//                     time_status: "Completed"
//                 };
//             }
//         }

//         // 2. Find ongoing round
//         const ongoingRound = competition.rounds.find((r: any) => {
//             const start = new Date(r.start_date_time);
//             const end = new Date(r.end_date_time);
//             return start <= now && now <= end;
//         });

//         if (ongoingRound) {
//             return {
//                 ...ongoingRound,
//                 status: "ongoing",
//                 time_status: "Ongoing now"
//             };
//         }

//         // 3. Find nearest upcoming round
//         const upcomingRounds = competition.rounds
//             .filter((r: any) => new Date(r.start_date_time) > now)
//             .sort(
//                 (a: any, b: any) =>
//                     new Date(a.start_date_time).getTime() - new Date(b.start_date_time).getTime()
//             );

//         if (upcomingRounds.length > 0) {
//             const upcomingRound = upcomingRounds[0];
//             return {
//                 ...upcomingRound,
//                 status: "upcoming",
//                 time_status: calculateDurations(new Date(upcomingRound.start_date_time))
//             };
//         }

//         // 4. No valid round found
//         console.warn(`No valid round (ongoing/upcoming) found for competition: ${competitionId}`);
//         return null;

//     } catch (error) {
//         console.error("Error determining current/upcoming round:", error);
//         return null; // Never throw — keep helper safe
//     }
// };

export const totalVotesCount = async (
    competition_object_id: ObjectId,
    round_object_id: ObjectId,
    participant_object_id: ObjectId
): Promise<number> => {
    try {
        console.log("++++++++++++++++++++++++++++++++++", competition_object_id,
            round_object_id,
            participant_object_id);

        const votes = await VoteModel.find({
            competition_object_id: competition_object_id,
            round_object_id: round_object_id,
            participant_object_id: participant_object_id
        });
        // console.log("++++++++++++++++++++++++++++++++++", votes);
        let totalVotes = 0;
        for (const vote of votes) {
            if (vote.vote_earned !== null && vote.vote_earned !== undefined) {
                totalVotes += vote.vote_earned;
            }
        }
        return totalVotes;

    } catch (error) {
        console.error("Error counting votes:", error);
        // Optionally: throw error or return 0 based on your error policy
        return 0;
    }
};

// **************************************************************************************************
// **************************************************************************************************
const formatDate = (date: Date | string): string => {
    return new Date(date).toISOString();
};

const calculateDurationss = (startDate: Date): string => {
    const now = new Date();
    const diffMs = startDate.getTime() - now.getTime();
    const diffSecs = Math.floor(diffMs / 1000);
    const diffMins = Math.floor(diffSecs / 60);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffDays > 0) return `in ${diffDays} day(s)`;
    if (diffHours > 0) return `in ${diffHours} hour(s)`;
    if (diffMins > 0) return `in ${diffMins} minute(s)`;
    return `in ${diffSecs} second(s)`;
};

export const currentRoundss = async (
    competitionId: string,
    type: string | null = null
): Promise<any> => {

    console.log("Fetching current round for competition ID:", competitionId);

    const competition = await CompetitionModel.findById(competitionId);

    if (!competition || !competition.rounds || competition.rounds.length === 0) {
        return {
            success: false,
            message: "No rounds found",
            statusCode: 404,
        };
    }

    const now = new Date();
    const challengeEndDate = new Date(competition.challenge_end_date);
    let status: RoundStatus | null = null;
    if (type) {
        status = type as RoundStatus;
    } else {
        if (now >= challengeEndDate) {
            status = 'completed';
        } else {
            const ongoing = competition.rounds.some((r: any) => {
                const start = new Date(r.start_date_time);
                const end = new Date(r.end_date_time);
                return start <= now && now <= end;
            });
            status = ongoing ? 'ongoing' : 'upcoming';
        }
    }

    let result: any | null = null;
    console.log("status", status);

    switch (status) {
        case 'completed': {
            const completedRounds = competition.rounds
                .filter((r: any) => new Date(r.end_date_time) <= challengeEndDate)
                .sort((a: any, b: any) => new Date(b.end_date_time).getTime() - new Date(a.end_date_time).getTime());
            if (completedRounds.length === 0) {
                return false;
            }

            const last = completedRounds[0];
            result = formatRoundResponse('completed', 'Completed', last);
            break;
        }

        case 'ongoing': {
            const ongoingRound = competition.rounds.find((r: any) => {
                const start = new Date(r.start_date_time);
                const end = new Date(r.end_date_time);
                return start <= now && now <= end;
            });

            if (!ongoingRound) {
                // This should not happen due to prior check, but safe guard
                return false;
            }

            result = formatRoundResponse('ongoing', 'Ongoing now', ongoingRound);
            break;
        }

        case 'upcoming': {
            const upcomingRounds = competition.rounds
                .filter((r: any) => new Date(r.start_date_time) > now)
                .sort((a: any, b: any) => new Date(a.start_date_time).getTime() - new Date(b.start_date_time).getTime());
            if (upcomingRounds.length === 0) {
                return false;
            }

            const upcoming = upcomingRounds[0];
            const timeStatus = calculateDurationss(new Date(upcoming.start_date_time));
            result = formatRoundResponse('upcoming', timeStatus, upcoming);
            break;
        }
        default:
            return false;
    }

    return result
};

// Helper to format round into standardized response
function formatRoundResponse(
    status: RoundStatus,
    timeStatus: string,
    round: any
): any {
    return {
        status,
        time_status: timeStatus,
        round_no: round.round_no,
        price: round.price,
        start_date_time: formatDate(round.start_date_time),
        end_date_time: formatDate(round.end_date_time),
        free_voting_duration: round.free_voting_duration,
        no_of_participant_proceeding: round.no_of_participant_proceeding,
        additional_vote_package: round.additional_vote_package,
        checkpoints: round.checkpoints,
        _id: round._id,
    };
}
// *********************************************************************************************************************
// *********************************************************************************************************************
// *********************************************************************************************************************
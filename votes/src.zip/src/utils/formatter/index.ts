import { formatGroupOwnerResponse, formatGroupOwnersResponse } from "./groupOwnerResponseFormatter";
import { formatCompetitionCreatorResponse, formatCompetitionCreatorsResponse } from "./competitionCreatorResponseFormatter";
import { formatMemberResponse, formatMembersResponse } from "./memberResponseFormatter";
import { formatIndividualVoterResponse, formatIndividualVotersResponse } from "./individualVoterResponseFormatter";
import { formatParticipantResponse, formatParticipantsResponse } from "./participantResponseFormatter";

const formatter = {
	formatGroupOwnerResponse,
	formatGroupOwnersResponse,
	formatCompetitionCreatorResponse,
	formatCompetitionCreatorsResponse,
	formatMemberResponse,
	formatMembersResponse,
	formatIndividualVoterResponse,
	formatIndividualVotersResponse,
	formatParticipantResponse,
	formatParticipantsResponse
};
export default formatter;
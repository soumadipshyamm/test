import { IMemberResponse } from "../../@types/interfaces/formatter/member.interface";
import { IMember } from "../../@types/interfaces/member.interface";

export const formatMemberResponse = async (user: IMember): Promise<IMemberResponse> => {
    return {
        _id: user._id.toString(),
        role: user.role,
        member_id: user?.member_id?.toString() ?? null,
        first_name: user.first_name,
        middle_name: user.middle_name,
        last_name: user.last_name,
        email: user.email,
        user_name: user.user_name,
        date_of_birth: user.date_of_birth,
        gender: user.gender,
        phone_number: user.phone_number,
        phone_extension: user.phone_extension,
        address_line_1: user.address_line_1,
        address_line_2: user.address_line_2,
        city: user.city,
        state: user.state,
        country: user.country,
        contact_label: user.contact_label,
        member_status: user.member_status || null, // Ensure default value
        is_verified: user.is_verified || false, // Ensure default value
        is_subscribe: user.is_subscribe || false, // Ensure default value
    };
};

export const formatMembersResponse = async (users: IMember[]): Promise<IMemberResponse[]> => {
    const userResponses = await Promise.all(
        users.map(async (user) => {
            return {
                _id: user._id.toString(),
                role: user.role,
                member_id: user?.member_id?.toString() ?? null,
                first_name: user.first_name,
                middle_name: user.middle_name,
                last_name: user.last_name,
                email: user.email,
                user_name: user.user_name,
                date_of_birth: user.date_of_birth,
                gender: user.gender,
                phone_number: user.phone_number,
                phone_extension: user.phone_extension,
                address_line_1: user.address_line_1,
                address_line_2: user.address_line_2,
                city: user.city,
                state: user.state,
                country: user.country,
                contact_label: user.contact_label,
                member_status: user.member_status || null,
                is_verified: user.is_verified || false,
                is_subscribe: user.is_subscribe || false,
            };
        })
    );

    return userResponses; // Return the array of user responses
};

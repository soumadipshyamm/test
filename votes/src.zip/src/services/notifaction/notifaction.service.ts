// import notifactionModel from "../../model/notifaction.model";
import { getCurrentMongoDBFormattedDate } from "../date/date.service";

export const notifaction = async (noytifactionPayload: any) => {
	try {
		const notifaction = {
			title: noytifactionPayload.title,
			message: noytifactionPayload.message,
			member_id: noytifactionPayload.member_id,
			status: noytifactionPayload.status,
			created_at: getCurrentMongoDBFormattedDate(),
		};
		// return await new notifactionModel(notifaction).save();
	} catch (error: any) {
		console.log("Notifaction Error", error);
		throw error;
	}
};

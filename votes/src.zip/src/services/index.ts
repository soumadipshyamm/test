import {
	isDuplicateGroupOwnerEmailService,
	isDuplicateValueCheckService,
	isRegisteredEmailService,
	isDuplicateUserNameService,
	isRegisteredUsernameService,
	hashPassword,
	comparePassword,
	generateJWT,
	convertCaseInsensitiveForQuery
} from "./auth/auth.service";
import { isValidEmailService, generateId, generateOtp } from "./common/validEmail.service";
import { sendEmail } from "./common/sendEmail.service";
import { isValidUserNameService } from "./common/validUserName.service";
import { initCapitalize } from "./common/initCapitalize";
// import { processPayment } from "./payment/stripe.service";
import {
	addMinutesToDate,
	calculateAge,
	calculateAgeGroup,
	compareDate,
	dateDifference,
	dateTimeZoneConverter,
	formatDate,
	formatDateAsPayload,
	formateMongoDateNotificationService,
	formateMongoDateService,
	getAgeInDays,
	getCurrentMongoDBFormattedDate,
	getFormattedMongoDBDateEmailService,
	isTermDateMoreThanNintyDays
} from "./date/date.service";

const service = {
	auth: {
		isDuplicateGroupOwnerEmailService,
		isDuplicateValueCheckService,
		isRegisteredEmailService,
		isDuplicateUserNameService,
		isRegisteredUsernameService,
		hashPassword,
		comparePassword,
		generateJWT,
		convertCaseInsensitiveForQuery
	},
	common: {
		isValidEmailService,
		isValidUserNameService,
		initCapitalize,
		generateId,
		generateOtp,
		sendEmail
	},
	date: {
		formateMongoDateService,
		formateMongoDateNotificationService,
		addMinutesToDate,
		compareDate,
		formatDate,
		isTermDateMoreThanNintyDays,
		dateDifference,
		formatDateAsPayload,
		getCurrentMongoDBFormattedDate,
		calculateAge,
		getAgeInDays,
		calculateAgeGroup,
		getFormattedMongoDBDateEmailService,
		dateTimeZoneConverter
	},
	payment: {
		// processPayment
	},
};

export default service;

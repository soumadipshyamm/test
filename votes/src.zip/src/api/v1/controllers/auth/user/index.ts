import { changePassword, getProfile, updateProfile, userList, userDetails, getUserDetails, deleteUser } from "./user.controller";
const user = {
	changePassword,
	getProfile,
	updateProfile,
	userList,
	userDetails,
	getUserDetails,
	deleteUser,
};
export default user;

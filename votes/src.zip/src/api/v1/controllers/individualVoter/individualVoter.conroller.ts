import { Request, Response } from "express";
import { StatusCodes } from "http-status-codes";
import { MESSAGE } from "../../../../constants/message";
import cron from "node-cron";
import CompetitionModel from "../../../../model/competition.model";
import VoteModel from "../../../../model/vote.model";
import VotePackageModel from "../../../../model/votePackage.model";
import ParticipantModel from "../../../../model/participant.model";
import transactionModel from "../../../../model/transaction.model";
import GroupOwnerModel from "../../../../model/groupOwner.model";
import VotingSubscriptionModel from "../../../../model/votingSubscription.model";
import MemberModel from "../../../../model/member.model";
import { roles, ROLES } from "../../../../constants/roles/roles";
import { getDetailsByEmail } from "../../../../utils/helper";
import SavedCompetitionModel from "../../../../model/savedCompetition.model";
import { PARTICIPATION_STATUS, COMPETITION_STATUS, MEMBER_STATUS } from "../../../../constants/status/status";
import { cp } from "fs";
import path from "path";
import mongoose from "mongoose";
import { VOTINGTYPE } from "../../../../constants/votingType/votingType";

export const populerCompetitionList = async (req: Request, res: Response): Promise<any> => {
	try {
		const competitions = await CompetitionModel.find({ status: COMPETITION_STATUS.active })
			.sort({ createdAt: -1 }) // Most recent first
			.limit(5)
			.lean();

		return res.status(200).json({
			message: "Latest 5 active competitions fetched successfully",
			competitions
		});
	} catch (error) {
		console.error("Error fetching latest competitions:", error);
		return res.status(500).json({
			message: "Failed to fetch competitions",
			error: error
		});
	}
};

// export const voteHistoryList = async (req: Request, res: Response): Promise<any> => {
// 	try {
// 		const userDetails = await getDetailsByEmail(req.user.email);

// 		const { competitionId, participantId, roundId } = req.params;

// 		const voterId = userDetails?._id;
// 		// Build filter dynamically
// 		const filter: any = {
// 			voter_object_id: voterId,
// 		};

// 		if (competitionId) {
// 			filter.competition_object_id = competitionId;
// 		}

// 		if (participantId) {
// 			filter.participant_object_id = participantId;
// 		}
// 		if (roundId) {
// 			filter.round_object_id = roundId;
// 		}

// 		console.log("===================================================", filter);

// 		// Note: `round_object_id` is likely NOT in Vote schema (see below)
// 		// So we can't directly filter by `roundId` unless it exists

// 		let fetchVotes = await VoteModel.find(filter)
// 			.populate({
// 				path: 'competition_object_id',
// 				// populate: { path: 'round_object_id' }
// 			})
// 			.populate({
// 				path: 'participant_object_id',
// 			})
// 			.sort({ createdAt: -1 })
// 			.lean();

// 		console.log("===================================================", fetchVotes);

// 		if (!userDetails) {
// 			return res.status(StatusCodes.UNAUTHORIZED).json({
// 				message: 'User not authenticated.'
// 			});
// 		}

// 		return res.status(StatusCodes.OK).json({
// 			message: MESSAGE.get.succ,
// 			data: fetchVotes
// 		});
// 	} catch (error) {
// 		console.error(error);
// 		return res.status(StatusCodes.BAD_REQUEST).json({
// 			message: MESSAGE.get.fail,
// 			error
// 		});
// 	}
// };

export const voteHistoryList = async (req: Request, res: Response): Promise<any> => {
	try {
		const userDetails = await getDetailsByEmail(req.user.email);

		const { competitionId, participantId, roundId } = req.params;

		if (!userDetails) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: "User not authenticated."
			});
		}

		const voterId = userDetails?._id;

		// Build filter dynamically
		const filter: any = {
			voter_object_id: voterId
		};

		if (competitionId) {
			filter.competition_object_id = competitionId;
		}

		if (participantId) {
			filter.participant_object_id = participantId;
		}
		if (roundId) {
			filter.round_object_id = roundId;
		}

		let fetchVotes = await VoteModel.find(filter)
			.populate({
				path: "competition_object_id"
			})
			.populate({
				path: "participant_object_id"
			})
			.sort({ createdAt: -1 })
			.lean();

		// ✅ Group by competition but keep array response
		const groupedVotes = Object.values(
			fetchVotes.reduce((acc: any, vote: any) => {
				const compId = vote.competition_object_id?._id?.toString();
				if (!acc[compId]) {
					acc[compId] = {
						competition_object_id: vote.competition_object_id,
						votes: []
					};
				}
				acc[compId].votes.push(vote);
				return acc;
			}, {})
		);

		return res.status(StatusCodes.OK).json({
			message: MESSAGE.get.succ,
			data: groupedVotes // still an array ✅
		});
	} catch (error) {
		console.error(error);
		return res.status(StatusCodes.BAD_REQUEST).json({
			message: MESSAGE.get.fail,
			error
		});
	}
};

// export const voteHistoryRoundList = async (req: Request, res: Response): Promise<any> => {
// 	try {
// 		// 1. Authenticate user
// 		const userDetails = await getDetailsByEmail(req.user.email);
// 		if (!userDetails) {
// 			return res.status(StatusCodes.UNAUTHORIZED).json({
// 				message: "User not authenticated."
// 			});
// 		}

// 		const { competitionId, participantId } = req.params;

// 		// 2. Validate required params
// 		if (!competitionId || !participantId) {
// 			return res.status(StatusCodes.BAD_REQUEST).json({
// 				message: "Competition ID and Participant ID are required."
// 			});
// 		}

// 		const voterId = userDetails._id;

// 		// 3. Fetch votes
// 		const votes = await VoteModel.find({
// 			competition_object_id: competitionId,
// 			participant_object_id: participantId,
// 			voter_object_id: voterId
// 		})
// 			.populate("competition_object_id") // competition
// 			.populate("participant_object_id") // participant
// 			.lean()
// 			.exec();

// 		if (!votes || votes.length === 0) {
// 			return res.status(StatusCodes.NOT_FOUND).json({
// 				message: "No vote history found."
// 			});
// 		}

// 		// 4. Fetch competition (for rounds)
// 		const competition = await CompetitionModel.findById(competitionId).lean().exec();

// 		if (!competition) {
// 			return res.status(StatusCodes.NOT_FOUND).json({
// 				message: "Competition not found."
// 			});
// 		}

// 		// 5. Map rounds
// 		const roundMap = new Map(competition.rounds.map((round: any) => [round._id.toString(), round]));

// 		// 6. Aggregate votes per round
// 		const roundVoteSummary: Record<string, { freeVotes: number; paidVotes: number; totalVotes: number }> = {};

// 		votes.forEach((vote) => {
// 			const roundId = vote.round_object_id?.toString();
// 			if (!roundId) return;

// 			if (!roundVoteSummary[roundId]) {
// 				roundVoteSummary[roundId] = {
// 					freeVotes: 0,
// 					paidVotes: 0,
// 					totalVotes: 0
// 				};
// 			}

// 			roundVoteSummary[roundId].totalVotes += vote?.vote_earned ?? 0;

// 			if (vote.voting_type === "FREE") {
// 				roundVoteSummary[roundId].freeVotes += vote?.vote_earned ?? 0;
// 			} else if (vote?.voting_type === VOTINGTYPE.paid) {
// 				roundVoteSummary[roundId].paidVotes += vote?.vote_earned ?? 0;
// 			}
// 		});

// 		// 7. Build round_details with votes
// 		const roundDetails = Object.keys(roundVoteSummary)
// 			.map((roundId) => {
// 				const round = roundMap.get(roundId);
// 				if (!round) return null;

// 				const summary = roundVoteSummary[roundId];
// 				return {
// 					_id: round._id,
// 					round_no: round.round_no,
// 					start_date_time: round.start_date_time,
// 					end_date_time: round.end_date_time,
// 					price: round.price,
// 					status: round.status,
// 					checkpoints: round.checkpoints,
// 					votes: {
// 						total: summary.totalVotes,
// 						free: summary.freeVotes,
// 						paid: summary.paidVotes
// 					}
// 				};
// 			})
// 			.filter(Boolean);

// 		// 8. Final grouped response
// 		const result = {
// 			competition_object: votes[0].competition_object_id,
// 			participant_object: votes[0].participant_object_id,
// 			round_details: roundDetails
// 		};

// 		return res.status(StatusCodes.OK).json({
// 			message: "Vote history fetched successfully.",
// 			Result: result
// 		});
// 	} catch (error) {
// 		console.error("Error in voteHistoryRoundList:", error);
// 		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
// 			message: "Failed to fetch vote history.",
// 			error: error instanceof Error ? error.message : String(error)
// 		});
// 	}
// };

export const voteHistoryRoundList = async (req: Request, res: Response): Promise<any> => {
	try {
		// 1. Authenticate user
		const userDetails = await getDetailsByEmail(req.user.email);
		if (!userDetails) {
			return res.status(StatusCodes.UNAUTHORIZED).json({
				message: "User not authenticated."
			});
		}

		const { competitionId, participantId } = req.params;

		// 2. Validate required params
		if (!competitionId || !participantId) {
			return res.status(StatusCodes.BAD_REQUEST).json({
				message: "Competition ID and Participant ID are required."
			});
		}

		const voterId = userDetails._id;

		// 3. Fetch votes
		const votes = await VoteModel.find({
			competition_object_id: competitionId,
			participant_object_id: participantId,
			voter_object_id: voterId
		})
			.populate("competition_object_id") // competition
			.populate("participant_object_id") // participant
			.lean()
			.exec();

		if (!votes || votes.length === 0) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "No vote history found."
			});
		}

		// 4. Fetch competition (for rounds)
		const competition = await CompetitionModel.findById(competitionId).lean().exec();
		if (!competition) {
			return res.status(StatusCodes.NOT_FOUND).json({
				message: "Competition not found."
			});
		}

		// 5. Build round map
		const roundMap = new Map((competition.rounds ?? []).map((round: any) => [round._id.toString(), round]));

		// 6. Aggregate votes per round
		const roundVoteSummary: Record<string, { freeVotes: number; paidVotes: number; totalVotes: number }> = {};

		votes.forEach((vote) => {
			const roundId = vote.round_object_id?.toString();
			if (!roundId) return;

			const earned = vote?.vote_earned ?? 0;

			if (!roundVoteSummary[roundId]) {
				roundVoteSummary[roundId] = { freeVotes: 0, paidVotes: 0, totalVotes: 0 };
			}

			roundVoteSummary[roundId].totalVotes += earned;

			if (vote.voting_type === VOTINGTYPE.free) {
				roundVoteSummary[roundId].freeVotes += earned;
			} else if (vote.voting_type === VOTINGTYPE.paid) {
				roundVoteSummary[roundId].paidVotes += earned;
			}
		});

		// 7. Build round_details with votes
		const roundDetails = Object.keys(roundVoteSummary)
			.map((roundId) => {
				const round = roundMap.get(roundId);
				if (!round) return null;

				const summary = roundVoteSummary[roundId];
				return {
					_id: round._id,
					round_no: round.round_no,
					start_date_time: round.start_date_time,
					end_date_time: round.end_date_time,
					price: round.price,
					status: round.status,
					checkpoints: round.checkpoints,
					votes: {
						total: summary.totalVotes,
						free: summary.freeVotes,
						paid: summary.paidVotes
					}
				};
			})
			.filter(Boolean);

		// 8. Final grouped response
		const result = {
			competition_object: votes[0].competition_object_id, // populated competition object
			participant_object: votes[0].participant_object_id, // populated participant object
			round_details: roundDetails
		};

		return res.status(StatusCodes.OK).json({
			message: "Vote history fetched successfully.",
			Result: result
		});
	} catch (error) {
		console.error("Error in voteHistoryRoundList:", error);
		return res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
			message: "Failed to fetch vote history.",
			error: error instanceof Error ? error.message : String(error)
		});
	}
};

export const getCompetitionParticipantsList = async (req: Request, res: Response): Promise<any> => {
	try {
		const { competitionId } = req.params;

		// 1. Fetch competition details
		const competition = await CompetitionModel.findById(competitionId);
		if (!competition) {
			return res.status(StatusCodes.NOT_FOUND).json({ message: "Competition not found" });
		}

		// 2. Fetch participants
		const participants = await ParticipantModel.find({
			competition_object_id: competitionId
		});

		// 3. Aggregate votes per participant + round
		const votesAgg = await VoteModel.aggregate([
			{ $match: { competition_object_id: competition._id } },
			{
				$group: {
					_id: {
						participant_object_id: "$participant_object_id",
						round_object_id: "$round_object_id"
					},
					totalVotes: { $sum: "$vote_earned" }
				}
			}
		]);

		// Convert to lookup map: { participantId_roundId: totalVotes }
		const votesMap: Record<string, number> = {};
		votesAgg.forEach((v) => {
			const key = `${v._id.participant_object_id}_${v._id.round_object_id}`;
			votesMap[key] = v.totalVotes;
		});

		// 4. Group participants by participant_object_id
		const groupedParticipants: Record<string, any> = {};

		participants.forEach((p) => {
			const pid = p.participant_object_id.toString();
			const roundKey = `${p.participant_object_id}_${p.round_object_id}`;

			if (!groupedParticipants[pid]) {
				groupedParticipants[pid] = {
					participant_object_id: p.participant_object_id,
					participant_name: p.participant_name,
					rounds: [],
					totalVotes: 0
				};
			}

			const roundVotes = votesMap[roundKey] || 0;

			groupedParticipants[pid].rounds.push({
				round_no: p.round_no,
				round_object_id: p.round_object_id,
				status: p.status,
				votes: roundVotes
			});

			groupedParticipants[pid].totalVotes += roundVotes;
		});

		// 5. Response
		return res.status(StatusCodes.OK).json({
			competition: {
				_id: competition._id,
				name: competition.name,
				description: competition.description,
				no_of_rounds: competition.no_of_rounds,
				no_of_winner: competition.no_of_winner,
				status: competition.status,
				challenge_start_date: competition.challenge_start_date,
				challenge_end_date: competition.challenge_end_date
			},
			participants: Object.values(groupedParticipants)
		});
	} catch (error: any) {
		console.error("Error in voteHistory:", error);
		return res
			.status(StatusCodes.INTERNAL_SERVER_ERROR)
			.json({ message: "Something went wrong", error: error.message });
	}
};

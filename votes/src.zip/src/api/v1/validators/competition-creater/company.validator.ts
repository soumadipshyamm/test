import Joi from "joi";

export const companyManagementValidator = Joi.object({
    name: Joi.string().max(200).required().trim(),
    description: Joi.string().required()
});

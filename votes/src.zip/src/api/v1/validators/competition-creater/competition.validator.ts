import Joi from "joi";

export const competitionValidator = Joi.object({
    name: Joi.string()
        .max(200)
        .required()
        .trim(),

    challenge_start_date: Joi.date()
        .required(),

    challenge_end_date: Joi.date()
        .greater(Joi.ref('challenge_start_date'))
        .required(),

    competition_type: Joi.string()
        .required(),
    no_of_rounds: Joi.number()
        .integer()
        .min(1)
        .required(),

    rounds: Joi.array().items(Joi.object({
        round_no: Joi.number()
            .required(),

        price: Joi.number()
            .required(),

        start_date_time: Joi.date()
            .required(),

        end_date_time: Joi.date()
            .greater(Joi.ref('start_date_time'))
            .required(),

        additional_vote_package: Joi.string().optional(),

        checkpoints: Joi.string()
            .required(),

        free_voting_duration: Joi.number()
            .required(),

        no_of_participant_proceeding: Joi.number()
            .required()
    })).required(),

    feature_image: Joi.string()
        .required(),

    description: Joi.string()
        .required(),

    round_checkpoint_start_visibility: Joi.boolean()
        .required(),

    no_of_winner: Joi.number()
        .integer()
        .min(1)
        .required(),

    prizes: Joi.array().items(Joi.object({
        name: Joi.string()
            .max(100)
            .required(),

        type: Joi.string()
            .valid('money', 'gift', 'both')
            .required(),
        value: Joi.string()
            .required(),
        description: Joi.string()
            .optional().allow(""),
    })).required(),

    file_type: Joi.array().items(Joi.string()).required(),
    status: Joi.optional(),
    created_by: Joi.optional(),
    creator_company: Joi.string()
        .required(),
    creator_description: Joi.string()
        .optional(),
});

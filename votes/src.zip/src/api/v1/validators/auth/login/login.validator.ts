import Joi from "joi";
import { ROLES } from "../../../../../constants/roles/roles";

export const loginValidator = Joi.object({
	role: Joi.string().required().valid(ROLES.super_admin, ROLES.admin, ROLES.competition_creator, ROLES.individual_voter, ROLES.participant, ROLES.member),
	user_id: Joi.string().required(),
	password: Joi.string(),
	devices_token: Joi.string().optional()
});

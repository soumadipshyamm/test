import Joi from "joi";

export const competitionTypeAddValidator = Joi.object({
	competition_name: Joi.string().max(30),
	competition_description: Joi.string().min(1).max(300).required(),
	total_rounds: Joi.number().integer().min(1).max(13).required(),
});

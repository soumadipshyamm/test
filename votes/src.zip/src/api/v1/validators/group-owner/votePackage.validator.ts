import Joi from "joi";

export const votePackageAddValidator = Joi.object({
	package_name: Joi.string().max(30), // Allow empty string and max length of 30
	package_type: Joi.string().min(1).max(300).allow(), // Adjusted max length for description
	votes_package: Joi.array().allow("").optional(),
});

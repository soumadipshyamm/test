import { loginValidator } from "./auth/login/login.validator";
import {
	superAdminregistrationValidator,
	registrationValidator,
	memberRegistrationValidator,
	emailVerificationValidator,
	changePasswordValidator,
	adminEntryValidator
} from "./auth/registration/registration.validator";
import { competitionTypeAddValidator } from "./group-owner/competitionType.validator";
import { competitionValidator } from "./competition-creater/competition.validator";
import { votePackageAddValidator } from "./group-owner/votePackage.validator";
import { competitionAcceptRejectValidator } from "./group-owner/competitionAcceptReject.validator";
import { userValidator } from "./user/user.validator";
import { companyManagementValidator } from "./competition-creater/company.validator";
import { voteValidator } from "./vote/vote.validator";


export const validators = {
	loginValidator,
	superAdminregistrationValidator,
	registrationValidator,
	memberRegistrationValidator,
	emailVerificationValidator,
	changePasswordValidator,
	userValidator,
	adminEntryValidator,
	competitionTypeAddValidator,
	votePackageAddValidator,
	competitionValidator,
	competitionAcceptRejectValidator,
	companyManagementValidator,
	voteValidator
};

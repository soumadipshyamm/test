import express from "express";

const app = express();

// *************************************************
app.use("/auth", require("./auth/auth.routes"));
app.use("/user", require("./user/user.routes"));

app.use("/group-owner", require("./group-owner/group-owner.routes"));
app.use("/competition-creator", require("./competition_creator/competition_creator.routes"));
app.use("/individual-voter", require("./individual_voter/individual_voter.routes"));
app.use("/participant", require("./participant/participant.routes"));
app.use('/', require('./common/competition.routes'))
app.use('/', require('./common/votes.routes'))
app.use('/', require('./common/dashboard.routes'))
app.use('/transaction', require('./transaction/transaction.routes'))
// *************************************************
// app.use("/super-admin", require("./test/test.routes"));


//test routes
app.use("/test", require("./test/test.route"));

module.exports = app;

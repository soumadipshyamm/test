import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
import { validators } from "../../validators";
import {
	addCompetition,
	updateCompetition,
	// deleteCompetition
} from "../../controllers/competitionManagment/competition.controller";
import competitionCreatorAuth from "../../../../middlewares/auth/competitionCreatorAuth.middleware";
import { addCompany, deleteCompany, getCompanyDetails, listCompany, updateCompany } from "../../controllers/competitionManagment/companyManagment.controller";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";

const router = express.Router();

//competition managment
router.route("/competition").post(competitionCreatorAuth, validator(validators.competitionValidator, null), addCompetition);
router.route("/competition/:id").put(competitionCreatorAuth, validator(validators.competitionValidator, null), updateCompetition);
// router.route("/competition/:id").delete(competitionCreatorAuth, deleteCompetition);

//Company Management
router.route("/company-management").post(competitionCreatorAuth, validator(validators.companyManagementValidator, null), addCompany);
router.route("/company-management").get(generalAuth, listCompany);
router.route("/company-management/:id").get(generalAuth, getCompanyDetails);
router.route("/company-management/:id").put(competitionCreatorAuth, validator(validators.companyManagementValidator, null), updateCompany);
router.route("/company-management/:id").delete(competitionCreatorAuth, deleteCompany);

module.exports = router;
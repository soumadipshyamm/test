import express from "express";
import participantAuth from "../../../../middlewares/auth/participantAuth.middleware";
import {
    addVote,
    addVoteSubscription,
    addParticipant,
    participantCompetitionDetails,
    uploadContent,
    ongoingCompetitionList,
    removeCompetition,
    saveCompetition,
    saveCompetitionList,
    upcommingCompetitionList,
    completedCompetitionList,
    completedCompetitionRoundList,
    completedCompetitionRoundDetailsList,
    verifyPayment,
    participantRePayment,
    veryfactionVoteSubscription,
    getParticipantTotalVotes
} from "../../controllers/competitionManagment/participant.controller"
import { upload } from "../../../../middlewares/multer.middleware";
import { validators } from "../../validators";
import validator from "../../../../middlewares/validator/validator.middleware";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";

const router = express.Router();

router.route("/participate").post(participantAuth, addParticipant);
router.route("/participant-competition-details/:competitionId?/:roundId?/:participantId?").get(generalAuth, participantCompetitionDetails);
router.route("/verify-payment/:id").patch(generalAuth, verifyPayment);
router.route("/participant-re-payment").post(generalAuth, participantRePayment);

router.route("/save-competition").post(generalAuth, saveCompetition);
router.route("/save-competition").delete(generalAuth, removeCompetition);
router.route("/save-competition").get(generalAuth, saveCompetitionList);
router.route("/ongoing-competition").get(generalAuth, ongoingCompetitionList);
router.route("/upcomming-competition").get(generalAuth, upcommingCompetitionList);
router.route("/completed-competition").get(generalAuth, completedCompetitionList);
router.route("/completed-competition-rounnd-list/:competitionId?").get(generalAuth, completedCompetitionRoundList);
router.route("/completed-competition-round-details/:competitionId?/:roundId?").get(generalAuth, completedCompetitionRoundDetailsList);



router.route("/vote").post(generalAuth, validator(validators.voteValidator, null), addVote);
router.route("/vote-subscription").post(generalAuth, addVoteSubscription);
router.route("/veryfaction-vote-subscription/:id?").patch(generalAuth, veryfactionVoteSubscription);

//fetch participant votes
router.route("/fetch-participant-votes/:competitionId?/:roundId?/:participantId?").get(generalAuth, getParticipantTotalVotes);

router.route("/upload-content").post(participantAuth, (req, res, next) => {
    upload.fields([{ name: "content" }
        , { name: "thumbnail" }
    ])(req, res, (err) => {
        if (err) {
            return res.status(400).json({ message: err.message });
        }
        uploadContent(req, res);
    });
});

module.exports = router;
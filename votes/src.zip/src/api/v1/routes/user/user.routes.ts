import express from "express";
import validator from "../../../../middlewares/validator/validator.middleware";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
const multer = require('multer');
const upload = multer();
import { validators } from "../../validators";
import user from "../../controllers/auth/user";

const router = express.Router();

// After Authentication
router.route("/password-change").post(generalAuth, validator(validators.changePasswordValidator, null), user.changePassword);
router.route("/get-profile").get(generalAuth, user.getProfile);
router.route("/update-profile").put(generalAuth, upload.none(), validator(validators.userValidator, null), user.updateProfile);
// router.route("/update-profile").post(generalAuth, upload.fields([{ name: "employee_photo", maxCount: 1 }]), validator(validators.userValidator, null), updateProfile);

router.route("/users").post(generalAuth, user.userList);
router.route("/get-user").post(generalAuth, user.userDetails);
router.route("/get-user-details/:id?").get(generalAuth, user.getUserDetails);
router.route("/delete-user").delete(generalAuth, user.deleteUser);

module.exports = router;
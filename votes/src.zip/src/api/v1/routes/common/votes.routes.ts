import express from "express";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
import validator from "../../../../middlewares/validator/validator.middleware";
import { validators } from "../../validators";
import { voteHistoryList, voteHistoryRoundList, populerCompetitionList, getCompetitionParticipantsList } from "../../controllers/individualVoter/individualVoter.conroller";

const router = express.Router();

router.route("/vote-history/:competitionId?/:participantId?/:roundId?").get(generalAuth, voteHistoryList);
router.route("/vote-history-round-list/:competitionId?/:participantId?").get(generalAuth, voteHistoryRoundList);
router.route("/vote-history-participant-list/:competitionId?").get(generalAuth, getCompetitionParticipantsList);
// router.route("/vote-history/:competitionId?/:roundId?/:participantId?").get(generalAuth, voteHistoryList);
router.route("/populer-competition-list").get(populerCompetitionList);

module.exports = router;
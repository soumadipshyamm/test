import express from "express";
import {
	dashboardReport
} from "../../controllers/competitionManagment/competition.controller";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";

const router = express.Router();

router.route("/dashboard-report").get(generalAuth, dashboardReport);

module.exports = router;
import express from "express";
// import validator from "../../../../middlewares/validator/validator.middleware";
// import memberAuth from "../../../../middlewares/auth/memberAuth.middleware";
// import { validators } from "../../validators";
// import { upload } from "../../../../middlewares/multer.middleware";
// import {
// 	currentRound
// } from "../../controllers/test/test.controller";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
// import { participantMoveToNextRound } from "../../controllers/competitionManagment/competition.controller";
// import { testConnection } from "../../controllers/test/test.connection";
const router = express.Router();

// router.use(generalAuth); // Using the middleware correctly

// router.route("/payment").post(generalAuth, testStripePayment);

// router.route("/sms").post(generalAuth, testSmsSend);
// router.route("/test-connection").get(testConnection);
// router.route("/image-upload").post(generalAuth, upload.fields([{ name: "dog_photo", maxCount: 1 }]), testImageUpload);

// router.route("/send-push-notifaction").post(sendPushgNotifaction);
// router.route("/send-notifaction").post(sendNotifaction);
// router.route("/send-notifaction-list/:id").get(notifactionList);
// router.route("/current-round").get(currentRound);
// router.route("/participantMoveToNextRound").get(participantMoveToNextRound);

module.exports = router; // Exporting the router

import express from "express";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
import {
	createPayment, receivedPaymentDeatils, transactionDeatils, transactionList, transactionUpdate,
	verifyPayment
} from "../../controllers/transaction/transaction.controller";

const router = express.Router();

// router.use(generalAuth); // Using the middleware correctly

router.route("/transaction-list/:id").get(generalAuth, transactionList);
router.route("/transaction-deatils-list").post(generalAuth, transactionDeatils);
router.route("/transaction-update").post(generalAuth, transactionUpdate);
router.route("/received-payment").post(generalAuth, receivedPaymentDeatils);
router.route("/verify-payment/:id").put(generalAuth, verifyPayment);
router.route("/create-payment").post(generalAuth, createPayment);

module.exports = router; // Exporting the router

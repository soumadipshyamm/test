import express from "express";
import generalAuth from "../../../../middlewares/auth/generalAuth.middleware";
import validator from "../../../../middlewares/validator/validator.middleware";
import { validators } from "../../validators";
import { voteHistoryList } from "../../controllers/individualVoter/individualVoter.conroller";

const router = express.Router();



module.exports = router;